/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Institutional Precision Clinical Informatics palette (see marieam/DESIGN.md)
        primary: {
          DEFAULT: 'var(--color-primary)',
          hover: 'var(--color-primary-hover)',
          container: 'var(--color-primary-container)',
        },
        secondary: {
          DEFAULT: 'var(--color-secondary)',
          container: 'var(--color-secondary-container)',
        },
        tertiary: {
          DEFAULT: 'var(--color-tertiary)',
          container: 'var(--color-tertiary-container)',
        },
        warning: 'var(--color-warning)',
        success: 'var(--color-success)',
        info: 'var(--color-info)',
        danger: 'var(--color-danger)',
        surface: {
          DEFAULT: 'var(--color-surface)',
          dim: 'var(--color-surface-dim)',
          bright: 'var(--color-surface-bright)',
          lowest: 'var(--color-surface-lowest)',
          low: 'var(--color-surface-low)',
          high: 'var(--color-surface-high)',
          highest: 'var(--color-surface-highest)',
        },
        ink: {
          DEFAULT: 'var(--color-text-primary)',
          muted: 'var(--color-text-secondary)',
          subtle: 'var(--color-text-muted)',
        },
        outline: {
          DEFAULT: 'var(--color-border)',
          variant: 'var(--color-border-subtle)',
        },
      },
      fontFamily: {
        heading: ['"IBM Plex Sans"', 'Alexandria', 'system-ui', 'sans-serif'],
        body: ['Inter', 'Alexandria', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      borderRadius: {
        xs: '0.25rem',
        card: '0.5rem',
        modal: '0.75rem',
      },
      boxShadow: {
        'level-2': '0 1px 3px 0 rgba(15, 23, 42, 0.05)',
        'level-3': '0 4px 12px -2px rgba(15, 23, 42, 0.08)',
        'level-4': '0 12px 32px -4px rgba(15, 23, 42, 0.16)',
      },
      keyframes: {
        pulseDot: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.35 },
        },
        tickerFade: {
          '0%': { opacity: 0, transform: 'translateY(2px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
      },
      animation: {
        'pulse-dot': 'pulseDot 1.8s ease-in-out infinite',
        'ticker-fade': 'tickerFade 0.4s ease-out',
      },
    },
  },
  plugins: [],
};
