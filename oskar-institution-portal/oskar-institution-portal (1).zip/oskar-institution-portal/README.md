# OSKAR MedStat — Institutional Administration & Hierarchy Portal

Production-ready React frontend for the **Institution role** of the OSKAR
MedStat medical research platform: institutional overview, legacy-researcher
domain discovery, supervisor workload governance, two-way consent connection
requests, studies & privacy governance, granular sub-admin permissions with
DPA export, and an institution setup wizard.

## Stack

- **React 18** (functional components + hooks only)
- **React Router 6** for the route shell
- **Vite** for dev/build tooling
- **Tailwind CSS**, themed entirely through CSS custom properties so light
  and dark mode are a single `data-theme` / `.dark` class swap — no
  duplicated utility classes
- Zero external UI kit — all primitives (`Button`, `Badge`, `Card`, `Modal`,
  `Drawer`, `Table`, meters, a dependency-free stacked bar chart, etc.) live
  in `src/ui/` so the bundle stays small and fully on-brand

No backend is wired up: all data flows through `src/context/InstitutionDataContext.jsx`,
which wraps `src/data/mockData.js` behind the same async signatures a real
REST/GraphQL client would expose (`await connectCandidate(id)`, `await
decideRequest(id, 'accepted')`, etc.). Swapping in a live API means editing
only that one file.

## Getting started

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production bundle -> dist/
npm run preview  # serve the production build locally
```

## Project structure

```
src/
  i18n/                 EN/AR dictionary + I18nContext (locale, dir, t())
  theme/                ThemeContext (light/dark, persisted, system-aware)
  data/mockData.js       Institution → College → Department → Supervisor →
                          Researcher → Study seed data
  context/
    InstitutionDataContext.jsx   Mock-API state layer used by every page
  hooks/
    useComplianceTelemetry.js    Powers the live compliance ticker
  ui/                    Reusable design-system primitives (Button, Badge,
                          Card/StatCard, Meters, Modal, Drawer, Tabs, Table,
                          Icon, StackedBarChart)
  layout/                Header, NavTabs, ComplianceTicker, Footer, AppShell
  components/
    ResearcherProfileDrawer.jsx
    MatchEngineModal.jsx
  pages/
    InstDashboard.jsx           Institutional Overview
    DomainUserDiscovery.jsx     Matching Engine / legacy user discovery
    SupervisorsView.jsx         Faculty workload & load distribution
    ConnectionRequests.jsx      Two-way consent request tracking
    StudiesAnalytics.jsx        Studies & privacy governance
    PermissionsMatrix.jsx       Sub-admin delegation + DPA export
    SetupWizard.jsx             Institution onboarding + branding
    NotFound.jsx
```

## Design system contract

Colors, spacing, typography and component rules follow the institutional
palette defined for this portal (`precision_clinical_informatics/DESIGN.md`),
reconciled with the platform-wide shell rules from the OSKAR MedStat design
system (`marieam/*.md`):

- **Primary** `#00A896` (light) / `#2DD4C4` (dark) — teal, used for primary
  actions, links, and active nav state
- **Secondary** `#0F172A` (light) / `#CBD5E1` (dark) — navy, used for
  institutional/tier badges
- **Warning / coral** `#DF7A59` — capacity alerts, PHI boundary banners
- **Success** `#059669`, **Info** `#2563EB`, **Danger** `#BA1A1A`
- All tokens are declared once in `src/index.css` as CSS custom properties
  under `:root`/`[data-theme='light']` and `[data-theme='dark']`, and
  consumed through Tailwind's `theme.extend.colors` so every utility class
  (`bg-primary`, `text-ink-muted`, …) is theme-aware automatically.

### RTL / bilingual behavior

- Toggling the header language switch flips `<html dir>` between `ltr` and
  `rtl` and swaps the full EN/AR string table.
- Per the platform's shell rules, the **authenticated header stays a fixed
  LTR structural shell** in both languages (logo pinned start, utility
  cluster pinned end) — only page content mirrors.
- Directional icons (chevrons, arrows) get `.icon-flip-rtl` so they still
  point the correct reading direction in Arabic.

### Live Compliance Ticker

`src/layout/ComplianceTicker.jsx` + `src/hooks/useComplianceTelemetry.js`
implement the required "live secure medical environment" banner: a
session-expiry countdown, an IRB Protocol Vault sync pulse, and a jittering
latency reading, all ticking client-side every second.

## Extending with a real backend

Every mutation in `InstitutionDataContext` already awaits a promise
(`connectCandidate`, `rebalanceSupervisor`, `decideRequest`,
`batchAcceptPending`, `togglePermission`, …). Replace the `delay()` +
`setState` bodies with real `fetch`/GraphQL calls and the entire UI layer —
loading states, optimistic pending flags (`pendingOps`), disabled buttons —
keeps working unchanged.
