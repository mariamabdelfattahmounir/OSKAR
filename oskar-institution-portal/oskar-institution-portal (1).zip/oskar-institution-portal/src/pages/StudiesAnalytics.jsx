import { useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import Tabs from '../ui/Tabs';
import { Card, SectionHeader, StatCard } from '../ui/Card';
import { ProgressBar } from '../ui/Meters';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import StackedBarChart from '../ui/StackedBarChart';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';

export default function StudiesAnalytics() {
  const { t } = useI18n();
  const {
    studyProductivity: p,
    departmentOutputSeries: series,
    statisticalToolDistribution: tools,
    complianceVerification: comp,
    oversightStudies,
  } = useInstitutionData();
  const [range, setRange] = useState('12m');
  const [search, setSearch] = useState('');

  const chartSeries = [
    { name: 'Oncology', color: '#0f172a', data: series.oncology },
    { name: 'Cardiology', color: '#00a896', data: series.cardiology },
    { name: 'Neurology', color: '#df7a59', data: series.neurology },
  ];

  const filteredStudies = oversightStudies.filter(
    (s) => !search || s.title.toLowerCase().includes(search.toLowerCase()) || s.protocolId.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-6">
      {/* Regulatory data boundary banner */}
      <Card className="p-5" style={{ backgroundColor: 'var(--color-warning-bg)', borderColor: 'rgba(223,122,89,0.35)' }}>
        <div className="flex items-start gap-3">
          <Icon name="warning" size={22} style={{ color: 'var(--color-warning)' }} className="shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-[13px] uppercase tracking-wide" style={{ color: 'var(--color-warning)' }}>
              {t('studies.boundaryTitle')}
            </p>
            <p className="text-[12.5px] text-ink-muted leading-relaxed mt-1 max-w-3xl">{t('studies.boundaryNote')}</p>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <Badge tone="danger">
                <Icon name="lock" size={12} />
                {t('studies.phiLocked')}
              </Badge>
              <Badge tone="info">
                <Icon name="fact_check" size={12} />
                {t('studies.part11Active')}
              </Badge>
              <Badge tone="audit">
                <Icon name="visibility_off" size={12} />
                {t('studies.zeroKnowledge')}
              </Badge>
            </div>
          </div>
        </div>
      </Card>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <SectionHeader title={t('studies.title')} subtitle={t('studies.subtitle')} />
        <Tabs
          items={[
            { value: '12m', label: t('studies.last12Months') },
            { value: 'year', label: t('studies.currentYear') },
            { value: 'all', label: t('studies.allTime') },
          ]}
          active={range}
          onChange={setRange}
        />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t('studies.activeClinical')} value={p.activeClinicalStudies.value} delta={p.activeClinicalStudies.delta} icon="monitor_heart" footnote={p.activeClinicalStudies.note} />
        <StatCard label={t('studies.completedStudies')} value={p.completedStudies.value} icon="task_alt" footnote={p.completedStudies.note} />
        <StatCard label={t('studies.exportVolumes')} value={p.statisticalExportVolumes.value} valueSuffix={p.statisticalExportVolumes.unit} icon="dataset" delta={p.statisticalExportVolumes.delta} />
        <StatCard label={t('studies.publications')} value={p.publications.value} icon="menu_book" footnote={p.publications.note} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="p-5 lg:col-span-3">
          <SectionHeader title={t('studies.outputCadence')} subtitle={t('studies.outputCadenceSub')} />
          <StackedBarChart categories={series.months} series={chartSeries} />
          <div className="flex items-center gap-4 mt-2 flex-wrap">
            {chartSeries.map((s) => (
              <span key={s.name} className="flex items-center gap-1.5 text-[11.5px] text-ink-muted">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: s.color }} />
                {s.name}
              </span>
            ))}
          </div>
        </Card>
        <Card className="p-5 lg:col-span-2">
          <SectionHeader title={t('studies.toolDistribution')} subtitle={t('studies.toolDistributionSub')} />
          <div className="flex flex-col gap-3 mb-4">
            {tools.map((tool) => (
              <div key={tool.name}>
                <div className="flex items-center justify-between text-[12px] mb-1">
                  <span className="text-ink font-medium truncate">{tool.name}</span>
                  <span className="font-data text-ink-muted">{tool.pct}%</span>
                </div>
                <ProgressBar pct={tool.pct} />
              </div>
            ))}
          </div>
          <div className="rounded-card p-3" style={{ backgroundColor: 'var(--color-success-bg)' }}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11.5px] font-bold text-success uppercase tracking-wide">{t('studies.complianceVerification')}</span>
              <span className="font-data text-[13px] font-bold text-success">{comp.pct}% GCP</span>
            </div>
            <p className="text-[11.5px] text-ink-muted leading-relaxed">{comp.label}</p>
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="p-5 pb-0">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-heading text-[15px] font-semibold text-ink">{t('studies.oversightDirectory')}</h2>
                <Badge tone="audit" dot={false}>{t('studies.zeroPhiExposure')}</Badge>
              </div>
              <p className="text-[12.5px] text-ink-muted mt-0.5 max-w-xl">{t('studies.oversightSub')}</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Icon name="search" size={16} className="absolute top-1/2 -translate-y-1/2 left-3 text-ink-subtle" />
                <input className="input-field ps-9 w-56" placeholder={t('studies.searchProtocol')} value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <Button variant="secondary" size="md" icon="filter_list">{t('studies.filterPhase')}</Button>
              <Button variant="primary" size="md" icon="file_download">{t('studies.exportSummary')}</Button>
            </div>
          </div>
        </div>
        <Table>
          <Thead>
            <Th>{t('studies.protocolId')}</Th>
            <Th>{t('studies.studyDesign')}</Th>
            <Th>{t('studies.piFaculty')}</Th>
            <Th align="end">{t('studies.enrolledCohort')}</Th>
            <Th>{t('studies.dataState')}</Th>
            <Th align="end">{t('studies.instActions')}</Th>
          </Thead>
          <tbody>
            {filteredStudies.map((s) => (
              <Tr key={s.protocolId}>
                <Td>
                  <p className="font-data font-semibold text-primary flex items-center gap-1">
                    <Icon name="check_circle" size={13} className="text-success" />
                    {s.protocolId}
                  </p>
                  <p className="text-[11px] text-ink-subtle">Exp: {s.exp}</p>
                </Td>
                <Td className="max-w-sm">
                  <p className="font-semibold text-ink text-[13px] leading-snug">{s.title}</p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Badge tone="neutral" dot={false}>{s.phase}</Badge>
                    <span className="text-[11px] text-ink-subtle">{s.protocolRef}</span>
                  </div>
                </Td>
                <Td>
                  <div className="flex items-center gap-2">
                    <span
                      className="flex items-center justify-center w-7 h-7 rounded-full text-[10px] font-bold text-white shrink-0"
                      style={{ backgroundColor: 'var(--color-secondary)' }}
                    >
                      {s.piInitials}
                    </span>
                    <div className="min-w-0">
                      <p className="text-[12.5px] font-semibold text-ink truncate">{s.pi}</p>
                      <p className="text-[11.5px] text-ink-muted truncate">{s.faculty}</p>
                    </div>
                  </div>
                </Td>
                <Td align="end">
                  <p className="font-data font-semibold">N = {s.cohortN.toLocaleString()}</p>
                </Td>
                <Td>
                  <Badge tone="neutral">
                    <Icon name="lock" size={11} />
                    {s.dataState}
                  </Badge>
                  <p className="text-[11px] text-ink-subtle mt-1">{t('studies.metadataOnly')}</p>
                </Td>
                <Td align="end">
                  <Button variant="secondary" size="sm" icon="key">
                    {t('studies.requestClearance')}
                  </Button>
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
        <div className="flex items-center justify-between px-5 py-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
          <p className="text-[12px] text-ink-muted">
            {t('common.showing')} {filteredStudies.length} {t('common.of')} {oversightStudies.length}
          </p>
        </div>
      </Card>

      <Card className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <Icon name="gpp_good" size={22} className="text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-[13px] text-ink">{t('studies.quarantineNote')}</p>
            <p className="text-[12px] text-ink-muted mt-0.5 max-w-2xl leading-relaxed">{t('studies.quarantineSub')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="secondary" size="sm" icon="verified_user">{t('studies.verifyHash')}</Button>
          <Button variant="secondary" size="sm" icon="print">{t('studies.printDossier')}</Button>
        </div>
      </Card>
    </div>
  );
}
