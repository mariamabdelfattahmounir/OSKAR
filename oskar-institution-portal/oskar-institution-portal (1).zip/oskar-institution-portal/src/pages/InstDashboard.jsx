import { Link } from 'react-router-dom';
import { useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Card, SectionHeader, StatCard } from '../ui/Card';
import { ProgressBar } from '../ui/Meters';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';
import { departments, departmentColorMap } from '../data/mockData';
import ResearcherProfileDrawer from '../components/ResearcherProfileDrawer';

const NODE_TONE = { success: 'success', warning: 'warning' };

export default function InstDashboard() {
  const { t } = useI18n();
  const { institution, dashboardMetrics, activityFeed, priorityProtocols, discoveryStats } =
    useInstitutionData();
  const [profileOpen, setProfileOpen] = useState(false);

  const totalDeptResearchers = departments.reduce((sum, d) => sum + d.researchers, 0);

  return (
    <div className="flex flex-col gap-6">
      {/* Institution identity strip */}
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-heading text-[22px] font-bold text-ink">{institution.name}</h1>
              <button
                className="inline-flex items-center gap-1 h-6 px-2 rounded-md text-[11px] font-semibold"
                style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}
                title={t('common.copy')}
              >
                <Icon name="content_copy" size={12} />
                {institution.shortCode}
              </button>
              <Badge tone="success">
                <Icon name="verified" size={12} />
                {t('dashboard.verifiedDomain')} {institution.domain}
              </Badge>
              <Badge tone="info">
                <Icon name="gavel" size={12} />
                {t('dashboard.irbRegistered')} #{institution.irbNumber}
              </Badge>
            </div>
            <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-ink-muted">{institution.description}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button variant="secondary" size="md" icon="download">
              {t('dashboard.downloadAudit')}
            </Button>
            <Button variant="primary" size="md" icon="person_add">
              {t('dashboard.inviteChair')}
            </Button>
          </div>
        </div>
      </Card>

      {/* Matching engine banner */}
      <Card className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4" style={{ backgroundColor: 'var(--color-info-bg)', borderColor: 'rgba(37,99,235,0.25)' }}>
        <div className="flex items-start gap-3">
          <span className="flex items-center justify-center w-9 h-9 rounded-md shrink-0" style={{ backgroundColor: 'var(--color-surface)', color: 'var(--color-info)' }}>
            <Icon name="person_search" size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-[14px] text-ink">
                {discoveryStats.candidatesIdentified} {t('dashboard.matchBannerTitle')}
              </h3>
              <Badge tone="warning">{t('dashboard.actionPending')}</Badge>
            </div>
            <p className="mt-0.5 text-[12.5px] text-ink-muted max-w-2xl">{t('dashboard.matchBannerSubtitle')}</p>
          </div>
        </div>
        <Link to="/discovery" className="shrink-0">
          <Button variant="primary" size="md" trailingIcon="arrow_forward">
            {t('dashboard.openMatchingEngine')}
          </Button>
        </Link>
      </Card>

      {/* Stat cards row */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          label={t('dashboard.totalUsers')}
          value={dashboardMetrics.totalUsers.value}
          delta={dashboardMetrics.totalUsers.deltaLabel}
          icon="group"
          footnote={`${dashboardMetrics.facultyCount} ${t('dashboard.faculty')} · ${dashboardMetrics.researchers.value} ${t('dashboard.fellows')}`}
        />
        <StatCard label={t('dashboard.supervisors')} value={dashboardMetrics.supervisors.value} icon="school">
          <p className="text-[12px] text-ink-muted mb-1">{dashboardMetrics.supervisors.activeDepts} {t('dashboard.activeDepts')}</p>
          <ProgressBar pct={dashboardMetrics.supervisorCapacity} label={`${t('common.of')} ${dashboardMetrics.supervisorCapacity}% capacity`} />
        </StatCard>
        <StatCard
          label={t('dashboard.researchers')}
          value={dashboardMetrics.researchers.value}
          delta={dashboardMetrics.researchers.deltaLabel}
          icon="stethoscope"
        />
        <StatCard label={t('dashboard.totalStudies')} value={dashboardMetrics.totalStudies.value} icon="science">
          <p className="text-[12px] text-ink-muted">{t('dashboard.cumulative')}</p>
          <p className="text-[12px] text-success font-semibold mt-1">{t('dashboard.gcpCompliant')} 100%</p>
        </StatCard>
        <StatCard label={t('dashboard.activeStudies')} value={dashboardMetrics.activeStudies.value} icon="folder_open">
          <p className="text-[12px] text-ink-muted mb-1">{dashboardMetrics.activeStudies.multicenter} {t('dashboard.multicenter')}</p>
          <ProgressBar pct={67} label={`${t('dashboard.enrolling')} (${dashboardMetrics.activeStudies.enrolling}) · ${t('dashboard.analysis')} (${dashboardMetrics.activeStudies.analysis})`} />
        </StatCard>
        <StatCard label={t('dashboard.pendingRequests')} value={dashboardMetrics.pendingRequests.value} accent="var(--color-warning)" icon="pending_actions">
          <p className="text-[12px] font-semibold" style={{ color: 'var(--color-warning)' }}>
            {dashboardMetrics.pendingRequests.urgent} {t('dashboard.urgent')}
          </p>
          <Link to="/requests" className="text-[12px] text-primary font-semibold inline-flex items-center gap-0.5 mt-1">
            {t('dashboard.reviewQueue')} <Icon name="chevron_right" size={14} flip />
          </Link>
        </StatCard>
      </div>

      {/* Departmental distribution + activity feed */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="p-5 lg:col-span-3">
          <SectionHeader
            title={t('dashboard.deptDistribution')}
            subtitle={t('dashboard.deptDistributionSub')}
            action={
              <span className="text-[12px] font-semibold text-ink-muted">
                {totalDeptResearchers} {t('dashboard.total')}
              </span>
            }
          />
          <div className="flex flex-col gap-3">
            {departments.map((d) => {
              const pct = ((d.researchers / totalDeptResearchers) * 100).toFixed(1);
              return (
                <div key={d.id}>
                  <div className="flex items-center justify-between text-[12.5px] mb-1">
                    <span className="flex items-center gap-2 font-medium text-ink">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: departmentColorMap[d.id] }} />
                      {d.name}
                    </span>
                    <span className="font-data text-ink-muted">{d.researchers} ({pct}%)</span>
                  </div>
                  <ProgressBar pct={Number(pct)} height={6} />
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t flex items-center justify-between gap-3 flex-wrap" style={{ borderColor: 'var(--color-border)' }}>
            <p className="text-[12px] text-ink-muted flex items-center gap-1.5">
              <Icon name="check_circle" size={14} className="text-success" />
              {t('dashboard.allDeptsGcp')}
            </p>
            <Link to="/supervisors" className="text-[12.5px] font-semibold text-primary inline-flex items-center gap-0.5">
              {t('dashboard.viewWorkloads')} <Icon name="arrow_forward" size={14} flip />
            </Link>
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <SectionHeader
            title={t('dashboard.instActivity')}
            subtitle={t('dashboard.instActivityLive')}
            action={
              <span className="flex items-center gap-1.5 text-[11px] font-bold" style={{ color: 'var(--color-audit)' }}>
                <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse-dot" />
                {t('dashboard.live')}
              </span>
            }
          />
          <ul className="flex flex-col gap-4">
            {activityFeed.map((a) => (
              <li key={a.id} className="flex gap-3">
                <span
                  className="flex items-center justify-center w-8 h-8 rounded-full shrink-0"
                  style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}
                >
                  <Icon
                    name={a.kind === 'affiliation' ? 'person_add' : a.kind === 'signoff' ? 'draw' : 'shield'}
                    size={16}
                  />
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-[12.5px] text-ink leading-snug">
                    <span className="font-semibold">{a.actor}</span> {a.role && <span className="text-ink-muted">· {a.role}</span>}
                  </p>
                  <p className="text-[12.5px] text-ink-muted leading-snug">{a.text}</p>
                  {a.meta && <p className="mt-0.5 font-data text-[11px] text-ink-subtle">{a.meta}</p>}
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[11px] text-ink-subtle">{a.time}</span>
                    {a.actions && (
                      <div className="flex gap-2">
                        {a.actions.map((act) => (
                          <button
                            key={act}
                            onClick={() => act === 'inspect' && setProfileOpen(true)}
                            className={`text-[11px] font-semibold px-2 h-6 rounded ${
                              act === 'authorize' ? 'text-white' : 'text-ink-muted'
                            }`}
                            style={act === 'authorize' ? { backgroundColor: 'var(--color-primary)' } : { backgroundColor: 'var(--color-surface-high)' }}
                          >
                            {act === 'authorize' ? t('requests.accept') : t('common.viewDetails')}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <button className="mt-4 text-[12.5px] font-semibold text-primary flex items-center gap-1">
            {t('dashboard.openAuditLog')} <Icon name="north_east" size={13} />
          </button>
        </Card>
      </div>

      {/* Priority protocols table */}
      <Card className="p-5">
        <SectionHeader
          title={t('dashboard.priorityProtocols')}
          subtitle={t('dashboard.priorityProtocolsSub')}
          action={
            <Link to="/studies" className="text-[12.5px] font-semibold text-primary">
              {t('dashboard.viewAllProtocols')}
            </Link>
          }
        />
        <Table>
          <Thead>
            <Th>{t('dashboard.irbId')}</Th>
            <Th>{t('dashboard.studyTitle')}</Th>
            <Th>{t('dashboard.principalSupervisor')}</Th>
            <Th>{t('dashboard.department')}</Th>
            <Th align="end">{t('dashboard.cohortN')}</Th>
            <Th>{t('dashboard.regulatoryNode')}</Th>
            <Th align="end">{t('dashboard.actions')}</Th>
          </Thead>
          <tbody>
            {priorityProtocols.map((p) => {
              const dept = departments.find((d) => d.id === p.departmentId);
              return (
                <Tr key={p.irbId}>
                  <Td mono className="font-semibold text-primary">{p.irbId}</Td>
                  <Td className="max-w-sm">{p.title}</Td>
                  <Td>{p.supervisor}</Td>
                  <Td>
                    <span
                      className="inline-flex items-center h-5 px-2 rounded text-[11px] font-semibold"
                      style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}
                    >
                      {dept?.name}
                    </span>
                  </Td>
                  <Td align="end" mono>{p.cohortN.toLocaleString()}</Td>
                  <Td>
                    <Badge tone={NODE_TONE[p.nodeState]}>{p.node}</Badge>
                  </Td>
                  <Td align="end">
                    <button className="btn btn-icon btn-outline btn-sm" aria-label="More">
                      <Icon name="more_horiz" size={16} />
                    </button>
                  </Td>
                </Tr>
              );
            })}
          </tbody>
        </Table>
      </Card>

      <ResearcherProfileDrawer open={profileOpen} onClose={() => setProfileOpen(false)} researcherId="RES-3301" />
    </div>
  );
}
