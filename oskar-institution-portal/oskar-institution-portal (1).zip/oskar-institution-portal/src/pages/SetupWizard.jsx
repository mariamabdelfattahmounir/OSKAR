import { useRef, useState } from 'react';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { Card } from '../ui/Card';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';
import { departments as seedDepartments } from '../data/mockData';

const STEPS = ['stepProfile', 'stepHierarchy', 'stepBranding', 'stepCompliance', 'stepReview'];

export default function SetupWizard() {
  const { t } = useI18n();
  const { institution } = useInstitutionData();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: institution.name,
    domain: institution.domain,
    irbNumber: institution.irbNumber,
    colleges: [{ id: 'c1', name: 'College of Medicine' }],
    departments: seedDepartments.map((d) => d.name),
    logoDataUrl: null,
    ack: false,
  });
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);

  const update = (patch) => setForm((prev) => ({ ...prev, ...patch }));

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => update({ logoDataUrl: reader.result });
    reader.readAsDataURL(file);
  };

  const addDepartment = () => {
    const name = prompt(t('setup.addDepartment'));
    if (name) update({ departments: [...form.departments, name] });
  };

  const addCollege = () => {
    const name = prompt(t('setup.addCollege'));
    if (name) update({ colleges: [...form.colleges, { id: `c${form.colleges.length + 1}`, name }] });
  };

  const next = () => setStep((s) => Math.min(STEPS.length - 1, s + 1));
  const back = () => setStep((s) => Math.max(0, s - 1));

  return (
    <div className="max-w-3xl mx-auto flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-[20px] font-bold text-ink">{t('setup.title')}</h1>
        <p className="text-[13px] text-ink-muted mt-1">{t('setup.subtitle')}</p>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-2 overflow-x-auto">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setStep(i)}
              className="flex items-center gap-2 h-9 px-3 rounded-full text-[12px] font-semibold whitespace-nowrap"
              style={{
                backgroundColor: i === step ? 'var(--color-primary)' : i < step ? 'var(--color-primary-container)' : 'var(--color-surface-high)',
                color: i === step ? '#fff' : i < step ? 'var(--color-primary)' : 'var(--color-text-secondary)',
              }}
            >
              {i < step ? <Icon name="check" size={14} /> : <span className="font-data">{i + 1}</span>}
              {t(`setup.${s}`)}
            </button>
            {i < STEPS.length - 1 && <span className="w-4 h-px" style={{ backgroundColor: 'var(--color-border-subtle)' }} />}
          </div>
        ))}
      </div>

      <Card className="p-6">
        {step === 0 && (
          <div className="flex flex-col gap-4">
            <Field label={t('setup.institutionName')}>
              <input className="input-field" value={form.name} onChange={(e) => update({ name: e.target.value })} />
            </Field>
            <Field label={t('setup.domain')}>
              <input className="input-field font-data" value={form.domain} onChange={(e) => update({ domain: e.target.value })} />
            </Field>
            <Field label={t('setup.irbNumber')}>
              <input className="input-field font-data" value={form.irbNumber} onChange={(e) => update({ irbNumber: e.target.value })} />
            </Field>
          </div>
        )}

        {step === 1 && (
          <div className="flex flex-col gap-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-[13.5px] text-ink">Colleges</h3>
                <Button variant="secondary" size="sm" icon="add" onClick={addCollege}>
                  {t('setup.addCollege')}
                </Button>
              </div>
              <ul className="flex flex-col gap-1.5">
                {form.colleges.map((c) => (
                  <li key={c.id} className="flex items-center gap-2 px-3 py-2 rounded-md text-[13px]" style={{ backgroundColor: 'var(--color-surface-low)' }}>
                    <Icon name="account_balance" size={16} className="text-primary" />
                    {c.name}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-[13.5px] text-ink">Departments</h3>
                <Button variant="secondary" size="sm" icon="add" onClick={addDepartment}>
                  {t('setup.addDepartment')}
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {form.departments.map((d) => (
                  <span key={d} className="inline-flex items-center gap-1 h-7 px-2.5 rounded-full text-[12px] font-medium" style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}>
                    <Icon name="apartment" size={13} />
                    {d}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col gap-4">
            <h3 className="font-semibold text-[13.5px] text-ink">{t('setup.uploadLogo')}</h3>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActive(false);
                handleFile(e.dataTransfer.files?.[0]);
              }}
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center justify-center gap-2 rounded-card border-2 border-dashed p-10 cursor-pointer text-center"
              style={{
                borderColor: dragActive ? 'var(--color-primary)' : 'var(--color-border-subtle)',
                backgroundColor: dragActive ? 'var(--color-primary-container)' : 'var(--color-surface-low)',
              }}
            >
              {form.logoDataUrl ? (
                <img src={form.logoDataUrl} alt="Institution logo preview" className="max-h-24 max-w-full object-contain" />
              ) : (
                <Icon name="cloud_upload" size={36} className="text-ink-subtle" />
              )}
              <p className="text-[13px] font-medium text-ink">{t('setup.dragDrop')}</p>
              <p className="text-[11.5px] text-ink-subtle">{t('setup.transparentNote')}</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/svg+xml"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0])}
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-col gap-4">
            <label className="flex items-start gap-3 p-4 rounded-card border cursor-pointer" style={{ borderColor: 'var(--color-border)' }}>
              <input
                type="checkbox"
                className="mt-0.5"
                checked={form.ack}
                onChange={(e) => update({ ack: e.target.checked })}
              />
              <span className="text-[13px] text-ink leading-relaxed">{t('setup.complianceAck')}</span>
            </label>
            <div className="flex items-center gap-2 text-[12.5px] text-ink-muted">
              <Icon name="policy" size={16} className="text-primary" />
              GCP E6(R2) · HIPAA Safe Harbor · FDA 21 CFR Part 11
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              {form.logoDataUrl ? (
                <img src={form.logoDataUrl} alt="logo" className="w-14 h-14 rounded-md object-contain border" style={{ borderColor: 'var(--color-border)' }} />
              ) : (
                <span className="flex items-center justify-center w-14 h-14 rounded-md" style={{ backgroundColor: 'var(--color-surface-high)' }}>
                  <Icon name="account_balance" size={24} className="text-ink-subtle" />
                </span>
              )}
              <div>
                <p className="font-semibold text-[15px] text-ink">{form.name}</p>
                <p className="text-[12.5px] font-data text-ink-muted">{form.domain} · IRB #{form.irbNumber}</p>
              </div>
            </div>
            <ReviewRow label="Colleges" value={form.colleges.map((c) => c.name).join(', ')} />
            <ReviewRow label="Departments" value={`${form.departments.length} configured`} />
            <ReviewRow label="Compliance" value={form.ack ? 'Attested' : 'Not yet attested'} />
          </div>
        )}
      </Card>

      <div className="flex items-center justify-between">
        <Button variant="secondary" size="md" icon="arrow_back" onClick={back} disabled={step === 0}>
          {t('common.back')}
        </Button>
        {step < STEPS.length - 1 ? (
          <Button variant="primary" size="md" trailingIcon="arrow_forward" onClick={next}>
            {t('common.next')}
          </Button>
        ) : (
          <Button variant="primary" size="md" icon="rocket_launch" disabled={!form.ack}>
            {t('setup.launch')}
          </Button>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-[12px] font-semibold text-ink-muted mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function ReviewRow({ label, value }) {
  return (
    <div className="flex items-center justify-between px-3 py-2 rounded-md text-[13px]" style={{ backgroundColor: 'var(--color-surface-low)' }}>
      <span className="text-ink-muted">{label}</span>
      <span className="font-medium text-ink">{value}</span>
    </div>
  );
}
