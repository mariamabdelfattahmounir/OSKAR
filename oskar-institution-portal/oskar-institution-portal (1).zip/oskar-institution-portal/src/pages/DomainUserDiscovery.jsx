import { useMemo, useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Card, StatCard } from '../ui/Card';
import { ConfidenceMeter } from '../ui/Meters';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';
import { departments } from '../data/mockData';
import MatchEngineModal from '../components/MatchEngineModal';

export default function DomainUserDiscovery() {
  const { t } = useI18n();
  const { institution, discoveryStats, candidates, connectCandidate, connectAllHighConfidence, pendingOps } =
    useInstitutionData();
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [modalState, setModalState] = useState(null); // { candidate, mode }

  const unlinked = candidates.filter((c) => c.status === 'unlinked');

  const filtered = useMemo(() => {
    return candidates.filter((c) => {
      const matchesSearch =
        !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.orcid.includes(search) ||
        (c.pmid || '').includes(search);
      const matchesDept = deptFilter === 'all' || c.department.toLowerCase().includes(deptFilter.toLowerCase());
      return matchesSearch && matchesDept;
    });
  }, [candidates, search, deptFilter]);

  return (
    <div className="flex flex-col gap-6">
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-start gap-4">
            <span
              className="flex items-center justify-center w-12 h-12 rounded-md shrink-0"
              style={{ backgroundColor: 'var(--color-secondary)', color: '#fff' }}
            >
              <Icon name="hub" size={24} />
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <Badge tone="info" dot={false}>ENGINE V2.4 · LIVE SYNCHRONIZER</Badge>
                <Badge tone="neutral" dot={false}>DOMAIN: {institution.domain}</Badge>
              </div>
              <h1 className="font-heading text-[19px] font-bold text-ink">{t('discovery.title')}</h1>
              <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-ink-muted">{t('discovery.subtitle')}</p>
            </div>
          </div>
          <div className="flex flex-col items-start lg:items-end gap-2 shrink-0">
            <div className="text-[12px] text-ink-muted">
              {t('discovery.unlinkedCandidates')}: <span className="font-data font-bold text-ink text-[15px] ms-1">{unlinked.length}</span>
            </div>
            <Button
              variant="primary"
              size="md"
              icon="send"
              loading={pendingOps['bulk-connect']}
              onClick={connectAllHighConfidence}
              disabled={unlinked.length === 0}
            >
              {t('discovery.requestAll')} ({unlinked.length})
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t('discovery.candidatesIdentified')} value={discoveryStats.candidatesIdentified} icon="groups" />
        <StatCard label={t('discovery.highConfidence')} value={discoveryStats.highConfidence} icon="verified" accent="var(--color-success)" />
        <StatCard label={t('discovery.discoveredPapers')} value={discoveryStats.discoveredPapers} icon="description" />
        <StatCard label={t('discovery.pendingReview')} value={discoveryStats.pendingManualReview} icon="flag" accent="var(--color-warning)" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Icon name="search" size={17} className="absolute top-1/2 -translate-y-1/2 left-3 text-ink-subtle" />
            <input
              className="input-field ps-9"
              placeholder={t('discovery.searchPlaceholder')}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select className="input-field md:w-52" value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}>
            <option value="all">{t('discovery.allDepartments')}</option>
            {departments.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name}
              </option>
            ))}
          </select>
          <Button variant="secondary" size="md" icon="tune">
            {t('discovery.refineCriteria')}
          </Button>
          <Button variant="secondary" size="md" icon="file_download">
            {t('discovery.exportManifest')}
          </Button>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <Table>
          <Thead>
            <Th>{t('discovery.researcherIdentity')}</Th>
            <Th>{t('discovery.discoveredEvidence')}</Th>
            <Th>{t('discovery.matchScore')}</Th>
            <Th align="end">{t('discovery.verificationAction')}</Th>
          </Thead>
          <tbody>
            {filtered.map((c) => (
              <Tr key={c.id}>
                <Td>
                  <div className="flex items-center gap-3">
                    <span
                      className="flex items-center justify-center w-9 h-9 rounded-full text-[12px] font-bold text-white shrink-0"
                      style={{ backgroundColor: 'var(--color-primary)' }}
                    >
                      {c.name.replace(/^(Dr\.|Prof\.)\s*/, '').split(' ').slice(0, 2).map((p) => p[0]).join('')}
                    </span>
                    <div className="min-w-0">
                      <p className="font-semibold text-ink text-[13px] flex items-center gap-1">
                        {c.name}
                        <Icon name="verified" size={13} className="text-primary" />
                      </p>
                      <p className="text-[12px] text-ink-muted truncate max-w-[220px]">{c.title}</p>
                      <p className="text-[11.5px] text-primary font-medium">{c.department}</p>
                    </div>
                  </div>
                </Td>
                <Td>
                  <p className="flex items-center gap-1.5 text-[12px] text-ink-muted font-data">
                    <Icon name="mail" size={13} />
                    {c.email}
                  </p>
                  <p className="text-[11.5px] font-data text-ink-subtle">
                    ORCID: {c.orcid} {c.pmid && `· PMID: ${c.pmid}`}
                  </p>
                  <p className="text-[11.5px] text-ink-muted mt-0.5">{c.evidence}</p>
                </Td>
                <Td>
                  <Badge tone={c.matchLevel} className="mb-1.5">
                    {c.matchType} · {c.confidence}%
                  </Badge>
                  <ConfidenceMeter confidence={c.confidence} ciLow={c.ciLow} ciHigh={c.ciHigh} tone={c.matchLevel} />
                  <p className="text-[11px] text-ink-subtle mt-0.5">{c.reliability}</p>
                </Td>
                <Td align="end">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => setModalState({ candidate: c, mode: 'proof' })}
                    >
                      {t('discovery.proof')}
                    </button>
                    {c.status === 'unlinked' ? (
                      <Button
                        variant="primary"
                        size="sm"
                        icon="link"
                        loading={pendingOps[c.id]}
                        onClick={() => setModalState({ candidate: c, mode: 'connect' })}
                      >
                        {t('discovery.connect')}
                      </Button>
                    ) : (
                      <Badge tone="success">{t('common.pending')}</Badge>
                    )}
                  </div>
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
        <div className="flex items-center justify-between px-4 py-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
          <p className="text-[12px] text-ink-muted">
            {t('common.showing')} {filtered.length} {t('common.of')} {discoveryStats.candidatesIdentified}
          </p>
          <Button variant="secondary" size="sm">{t('discovery.loadNext')}</Button>
        </div>
      </Card>

      <Card
        className="p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3"
        style={{ backgroundColor: 'var(--color-primary-container)', borderColor: 'rgba(0,168,150,0.3)' }}
      >
        <Icon name="key" size={20} className="text-primary shrink-0" />
        <div>
          <p className="font-semibold text-[13px] text-ink">{t('discovery.consentRequired')}</p>
          <p className="text-[12px] text-ink-muted leading-relaxed">{t('discovery.consentNote')}</p>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <InfoStrip icon="dns" title={t('discovery.indexStatus')} subtitle={t('discovery.externalPipeline')} note={t('discovery.pubmedNote')} />
        <InfoStrip icon="account_tree" title={t('discovery.hierarchyAllocation')} subtitle={t('discovery.autoAffiliation')} />
        <InfoStrip icon="draw" title={t('discovery.auditSafeguard')} subtitle={t('discovery.part11Sig')} note={t('discovery.part11Note')} />
      </div>

      <MatchEngineModal
        candidate={modalState?.candidate}
        mode={modalState?.mode}
        connecting={modalState && pendingOps[modalState.candidate.id]}
        onClose={() => setModalState(null)}
        onConnect={(id) => {
          connectCandidate(id);
          setModalState(null);
        }}
      />
    </div>
  );
}

function InfoStrip({ icon, title, subtitle, note }) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-1">
        <Icon name={icon} size={17} className="text-primary" />
        <p className="text-[12px] font-bold uppercase tracking-wide text-ink-subtle">{title}</p>
      </div>
      <p className="text-[13.5px] font-semibold text-ink">{subtitle}</p>
      {note && <p className="text-[12px] text-ink-muted mt-1 leading-relaxed">{note}</p>}
    </Card>
  );
}
