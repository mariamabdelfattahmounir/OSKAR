import { useMemo, useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Card, SectionHeader, StatCard } from '../ui/Card';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';

const STATUS_TONE = { pending: 'warning', accepted: 'success', declined: 'danger' };
const FILTERS = ['all', 'incoming', 'outgoing', 'archive'];

export default function ConnectionRequests() {
  const { t } = useI18n();
  const { institution, requests, connectionRequestSummary: sum, decideRequest, batchAcceptPending, resendPing, pendingOps } =
    useInstitutionData();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState([]);

  const filtered = useMemo(() => {
    return requests.filter((r) => {
      if (filter === 'incoming' && r.direction !== 'incoming') return false;
      if (filter === 'outgoing' && r.direction !== 'outgoing') return false;
      if (filter === 'archive' && r.status === 'pending') return false;
      if (search) {
        const q = search.toLowerCase();
        return r.id.toLowerCase().includes(q) || r.investigator.toLowerCase().includes(q) || r.department.toLowerCase().includes(q);
      }
      return true;
    });
  }, [requests, filter, search]);

  const pendingIncoming = requests.filter((r) => r.status === 'pending' && r.direction === 'incoming');

  const toggleSelect = (id) => {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const selectAllPending = () => {
    setSelected(pendingIncoming.map((r) => r.id));
  };

  return (
    <div className="flex flex-col gap-6">
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          <div>
            <p className="text-[11px] font-semibold text-ink-subtle uppercase tracking-wide">
              {t('requests.breadcrumb')}
            </p>
            <h1 className="font-heading text-[19px] font-bold text-ink mt-1">{t('requests.title')}</h1>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <Badge tone="success">
              <Icon name="bolt" size={12} />
              SLA 99.4%
            </Badge>
            <Button variant="primary" size="md" icon="send">
              {t('requests.dispatchToken')}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3" style={{ backgroundColor: 'var(--color-primary-container)' }}>
        <Icon name="key" size={20} className="text-primary shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-[13px] text-ink">{t('requests.policyTitle')}</p>
            <Badge tone="neutral" dot={false}>GCP E6(R2) §4.3 &amp; BYLAW 12-B</Badge>
          </div>
          <p className="text-[12px] text-ink-muted leading-relaxed mt-1 max-w-3xl">{t('requests.policyNote')}</p>
        </div>
        <button className="text-[12px] font-semibold text-primary whitespace-nowrap flex items-center gap-1 shrink-0">
          {t('requests.viewSpec')} <Icon name="north_east" size={13} />
        </button>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t('requests.incoming')} value={sum.incomingPending} icon="call_received" footnote={sum.incomingSlaNote} accent="var(--color-warning)" />
        <StatCard label={t('requests.outgoing')} value={sum.outgoingDispatched} icon="call_made" footnote={sum.outgoingNote} />
        <StatCard label={t('requests.dualConsent')} value={sum.dualConsentSealed} icon="verified" footnote={sum.dualConsentPeriod} accent="var(--color-success)" />
        <StatCard label={t('requests.credentialVerification')} value={`${sum.credentialScorePct}%`} icon="badge" footnote="ORCID / Scholar" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="flex items-center gap-1 overflow-x-auto">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className="shrink-0 h-8 px-3 rounded-md text-[12.5px] font-semibold whitespace-nowrap"
                style={{
                  backgroundColor: filter === f ? 'var(--color-primary)' : 'var(--color-surface-high)',
                  color: filter === f ? '#fff' : 'var(--color-text-secondary)',
                }}
              >
                {f === 'all' && t('requests.allRequests')}
                {f === 'incoming' && t('requests.incomingAffiliation')}
                {f === 'outgoing' && t('requests.outgoingInvitations')}
                {f === 'archive' && t('requests.historicalArchive')}
              </button>
            ))}
          </div>
          <div className="relative flex-1 min-w-[200px]">
            <Icon name="search" size={17} className="absolute top-1/2 -translate-y-1/2 left-3 text-ink-subtle" />
            <input className="input-field ps-9" placeholder={t('requests.searchPlaceholder')} value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
        </div>

        <div className="flex items-center justify-between mt-3 pt-3 border-t flex-wrap gap-2" style={{ borderColor: 'var(--color-border)' }}>
          <label className="flex items-center gap-2 text-[12.5px] font-semibold text-ink cursor-pointer">
            <input
              type="checkbox"
              checked={selected.length > 0 && selected.length === pendingIncoming.length}
              onChange={(e) => (e.target.checked ? selectAllPending() : setSelected([]))}
            />
            {t('requests.selectAllPending')} ({pendingIncoming.length}) · {t('requests.selected')}: {selected.length}
          </label>
          <div className="flex items-center gap-2">
            <Button
              variant="primary"
              size="sm"
              icon="verified"
              disabled={selected.length === 0}
              loading={pendingOps['batch-accept']}
              onClick={() => {
                batchAcceptPending(selected);
                setSelected([]);
              }}
            >
              {t('requests.batchAccept')}
            </Button>
            <Button variant="secondary" size="sm" icon="ios_share">
              {t('requests.batchExport')}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <Table>
          <Thead>
            <Th></Th>
            <Th>{t('requests.requestId')}</Th>
            <Th>{t('requests.investigatorRole')}</Th>
            <Th>{t('requests.deptBranch')}</Th>
            <Th>{t('requests.direction')}</Th>
            <Th>{t('requests.verificationProofs')}</Th>
            <Th>{t('requests.expirySla')}</Th>
            <Th>{t('requests.statusDecision')}</Th>
            <Th align="end">{t('requests.actions')}</Th>
          </Thead>
          <tbody>
            {filtered.map((r) => (
              <Tr key={r.id}>
                <Td>
                  {r.status === 'pending' && r.direction === 'incoming' && (
                    <input type="checkbox" checked={selected.includes(r.id)} onChange={() => toggleSelect(r.id)} />
                  )}
                </Td>
                <Td mono className="text-[11.5px] text-ink-muted">{r.id}</Td>
                <Td>
                  <div className="flex items-center gap-2">
                    <span
                      className="flex items-center justify-center w-8 h-8 rounded-full text-[11px] font-bold text-white shrink-0"
                      style={{ backgroundColor: 'var(--color-secondary)' }}
                    >
                      {r.initials}
                    </span>
                    <div className="min-w-0">
                      <p className="font-semibold text-ink text-[12.5px] truncate">{r.investigator}</p>
                      <p className="text-[11.5px] text-ink-muted truncate max-w-[180px]">{r.role}</p>
                    </div>
                  </div>
                </Td>
                <Td>
                  <p className="text-[12px] text-ink">{r.branch}</p>
                  <p className="text-[11.5px] text-ink-muted">{r.department}</p>
                </Td>
                <Td>
                  <span className="flex items-center gap-1 text-[12px] font-semibold text-ink-muted">
                    <Icon name={r.direction === 'incoming' ? 'south_west' : 'north_east'} size={14} />
                    {r.direction === 'incoming' ? t('requests.incoming') : t('requests.outgoing')}
                  </span>
                </Td>
                <Td>
                  <div className="flex flex-col gap-1">
                    {r.proofs.map((p) => (
                      <span key={p} className="flex items-center gap-1 text-[11.5px]" style={{ color: r.proofState === 'failed' ? 'var(--color-danger)' : 'var(--color-text-secondary)' }}>
                        <Icon name={r.proofState === 'failed' ? 'error' : r.proofState === 'partial' ? 'hourglass_top' : 'check_circle'} size={13} />
                        {p}
                      </span>
                    ))}
                  </div>
                </Td>
                <Td>
                  <p className="text-[12px] text-ink">{r.submitted}</p>
                  <p className="text-[11.5px] text-ink-muted">{r.sla}</p>
                </Td>
                <Td>
                  <Badge tone={STATUS_TONE[r.status]}>{t(`common.${r.status}`)}</Badge>
                  {r.declineReason && <p className="text-[11px] text-ink-subtle mt-1">Reason: {r.declineReason}</p>}
                </Td>
                <Td align="end">
                  <div className="flex items-center justify-end gap-1.5 flex-wrap">
                    {r.status === 'pending' && r.direction === 'incoming' && (
                      <>
                        <Button variant="primary" size="sm" icon="check" loading={pendingOps[r.id]} onClick={() => decideRequest(r.id, 'accepted')}>
                          {t('requests.accept')}
                        </Button>
                        <Button variant="danger" size="sm" icon="close" onClick={() => decideRequest(r.id, 'declined')}>
                          {t('requests.decline')}
                        </Button>
                      </>
                    )}
                    {r.status === 'pending' && r.direction === 'outgoing' && (
                      <Button variant="secondary" size="sm" icon="notifications_active" loading={pendingOps[`ping-${r.id}`]} onClick={() => resendPing(r.id)}>
                        {t('requests.resendPing')}
                      </Button>
                    )}
                    {r.status === 'accepted' && (
                      <Button variant="secondary" size="sm" icon="folder_shared">
                        {t('requests.credentialsDossier')}
                      </Button>
                    )}
                    {r.status === 'declined' && (
                      <Button variant="secondary" size="sm" icon="history">
                        {t('requests.auditLogAction')}
                      </Button>
                    )}
                  </div>
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <SectionHeader title={t('requests.cryptoAuditTitle')} icon="lock" action={<Badge tone="neutral" dot={false}>21 CFR PART 11</Badge>} />
          <div className="grid grid-cols-3 gap-3 text-[12px]">
            <MiniStat label="KEY 1" value="Valid · Signed" />
            <MiniStat label="KEY 2" value={`${sum.incomingPending} Pending Sig`} />
            <MiniStat label="IRB COUPLING" value="Zero-Knowledge" />
          </div>
          <Button variant="secondary" size="sm" icon="download" className="mt-4">
            {t('requests.downloadMerkle')}
          </Button>
        </Card>
        <Card className="p-5">
          <SectionHeader title={t('requests.quickResolution')} icon="rule" />
          <ul className="flex flex-col gap-2 mb-3">
            <li className="flex items-center justify-between px-3 py-2 rounded-md text-[12.5px]" style={{ backgroundColor: 'var(--color-surface-low)' }}>
              <span>Auto-Affiliate {institution.domain}</span>
              <Badge tone="success">ACTIVE</Badge>
            </li>
            <li className="flex items-center justify-between px-3 py-2 rounded-md text-[12.5px]" style={{ backgroundColor: 'var(--color-surface-low)' }}>
              <span>Strict GCP E6 Escalation</span>
              <Badge tone="success">ENABLED</Badge>
            </li>
          </ul>
          <Button variant="secondary" size="sm" icon="settings">
            {t('requests.configureRules')}
          </Button>
        </Card>
      </div>
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="rounded-card border p-2.5" style={{ borderColor: 'var(--color-border)' }}>
      <p className="text-[10px] font-bold uppercase tracking-wide text-ink-subtle">{label}</p>
      <p className="font-semibold text-ink mt-0.5">{value}</p>
    </div>
  );
}
