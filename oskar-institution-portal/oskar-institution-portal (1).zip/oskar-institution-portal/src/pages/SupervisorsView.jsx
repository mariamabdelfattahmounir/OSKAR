import { useMemo, useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import Tabs from '../ui/Tabs';
import { Card, StatCard } from '../ui/Card';
import { CapacityGauge } from '../ui/Meters';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';
import { departments } from '../data/mockData';
import ResearcherProfileDrawer from '../components/ResearcherProfileDrawer';

const BAND_TONE = { available: 'success', moderate: 'info', high: 'warning' };

export default function SupervisorsView() {
  const { t } = useI18n();
  const { supervisors, supervisorWorkloadSummary: s, rebalanceSupervisor, bulkRebalance, pendingOps } =
    useInstitutionData();
  const [deptFilter, setDeptFilter] = useState('all');
  const [filterText, setFilterText] = useState('');
  const [view, setView] = useState('cards');
  const [drawerResearcher, setDrawerResearcher] = useState(null);

  const filtered = useMemo(() => {
    return supervisors.filter((sup) => {
      const matchesDept = deptFilter === 'all' || sup.departmentId === deptFilter;
      const matchesText =
        !filterText ||
        sup.name.toLowerCase().includes(filterText.toLowerCase()) ||
        sup.id.toLowerCase().includes(filterText.toLowerCase());
      return matchesDept && matchesText;
    });
  }, [supervisors, deptFilter, filterText]);

  return (
    <div className="flex flex-col gap-6">
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <Badge tone="neutral" dot={false} className="mb-2">INSTITUTIONAL PORTAL · FACULTY WORKLOAD GOVERNANCE</Badge>
            <h1 className="font-heading text-[19px] font-bold text-ink">{t('supervisors.title')}</h1>
            <p className="mt-1 text-[12.5px] text-ink-muted">{t('supervisors.subtitle')}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button variant="secondary" size="md" icon="rule">
              {t('supervisors.capacityRules')}
            </Button>
            <Button variant="secondary" size="md" icon="file_download">
              {t('supervisors.exportAudit')}
            </Button>
            <Button
              variant="primary"
              size="md"
              icon="balance"
              loading={pendingOps['bulk-rebalance']}
              onClick={bulkRebalance}
            >
              {t('supervisors.initiateRebalance')}
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t('supervisors.supervisoryRatio')} value={s.ratio} icon="groups">
          <p className="text-[12px] text-ink-muted">{t('supervisors.targetThreshold')} ≤ {s.targetThreshold}</p>
          <p className="text-[12px] font-semibold text-success flex items-center gap-1 mt-0.5">
            <Icon name="check_circle" size={13} />
            {t('supervisors.inSafeBand')}
          </p>
        </StatCard>
        <StatCard label={t('supervisors.highCapacityAlert')} value={s.highCapacityCount} icon="warning" accent="var(--color-warning)">
          <p className="text-[12px] text-ink-muted">{t('supervisors.facultyOverLoad')}</p>
          <Badge tone="warning" className="mt-1">{s.highCapacityPctOfCorps}% {t('supervisors.ofCorps')}</Badge>
        </StatCard>
        <StatCard label={t('supervisors.irbActive')} value={s.irbActiveProtocols} delta={s.irbDelta} icon="policy">
          <p className="text-[12px] text-ink-muted">{s.traineesAudited} {t('supervisors.traineesAudited')} · {s.traineesAuditedPct}%</p>
        </StatCard>
        <Card className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold tracking-wide uppercase text-ink-subtle">{t('supervisors.guidelines')}</span>
            <Icon name="info" size={15} className="text-ink-subtle" />
          </div>
          <ul className="flex flex-col gap-1.5 text-[12px]">
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'var(--color-success)' }} />{t('supervisors.available')} (&lt;60%)</span>
              <span className="font-data font-semibold">{s.guidelineCounts.available} {t('supervisors.placements')}</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'var(--color-info)' }} />{t('supervisors.moderate')} (60-85%)</span>
              <span className="font-data font-semibold">{s.guidelineCounts.moderate} Faculty</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'var(--color-warning)' }} />{t('supervisors.highLoad')} (&gt;85%)</span>
              <span className="font-data font-semibold" style={{ color: 'var(--color-warning)' }}>{s.guidelineCounts.high} Capped</span>
            </li>
          </ul>
        </Card>
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="flex items-center gap-1 overflow-x-auto">
            <FilterChip active={deptFilter === 'all'} onClick={() => setDeptFilter('all')} label={t('supervisors.allDepartments')} />
            {departments.map((d) => (
              <FilterChip key={d.id} active={deptFilter === d.id} onClick={() => setDeptFilter(d.id)} label={d.name} />
            ))}
          </div>
          <div className="relative flex-1 min-w-[200px]">
            <Icon name="search" size={17} className="absolute top-1/2 -translate-y-1/2 left-3 text-ink-subtle" />
            <input
              className="input-field ps-9"
              placeholder={t('supervisors.filterPlaceholder')}
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
            />
          </div>
          <Tabs
            items={[
              { value: 'cards', label: t('supervisors.cards') },
              { value: 'density', label: t('supervisors.density') },
            ]}
            active={view}
            onChange={setView}
          />
        </div>
      </Card>

      {view === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((sup) => {
            const dept = departments.find((d) => d.id === sup.departmentId);
            return (
              <Card key={sup.id} className="p-4" accent={BAND_TONE[sup.band] === 'warning' ? 'var(--color-warning)' : BAND_TONE[sup.band] === 'success' ? 'var(--color-success)' : 'var(--color-info)'}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <p className="font-semibold text-[13.5px] text-ink truncate">{sup.name}</p>
                    <p className="text-[12px] text-ink-muted truncate">{sup.title}</p>
                    <p className="text-[11.5px] font-data text-primary">{sup.id} · {dept?.name}</p>
                  </div>
                  <button
                    className="btn btn-icon btn-outline btn-sm shrink-0"
                    onClick={() => setDrawerResearcher('RES-3301')}
                    aria-label="view"
                  >
                    <Icon name="visibility" size={15} />
                  </button>
                </div>

                <div className="flex items-center justify-between mb-1">
                  <Badge tone={BAND_TONE[sup.band]}>{t(`supervisors.${sup.band === 'high' ? 'highLoad' : sup.band}`)}</Badge>
                  <span className="font-data text-[13px] font-bold text-ink">{sup.utilizationPct}% {t('supervisors.utilized')}</span>
                </div>
                <CapacityGauge pct={sup.utilizationPct} capSlots={sup.capSlots} assigned={sup.assigned} />
                <p className="text-[11.5px] text-ink-muted mt-1">
                  {t('supervisors.capSlots')}: {sup.capSlots} {t('supervisors.slotsMax')} · {sup.assigned} {t('supervisors.assigned')} ({sup.note})
                </p>

                <div className="grid grid-cols-2 gap-3 my-3 pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                  <div>
                    <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-subtle">{t('supervisors.activeStudents')}</p>
                    <p className="font-data text-[16px] font-bold text-ink">{sup.activeResearchers}</p>
                  </div>
                  <div>
                    <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-subtle">{t('supervisors.activeStudies')}</p>
                    <p className="font-data text-[16px] font-bold text-ink">{sup.activeStudies}</p>
                    <p className="text-[11px] text-ink-muted">{sup.studiesNote}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant={sup.band === 'high' ? 'primary' : 'secondary'}
                    size="sm"
                    icon="balance"
                    className="flex-1"
                    loading={pendingOps[sup.id]}
                    onClick={() => rebalanceSupervisor(sup.id, -3)}
                  >
                    {t('supervisors.rebalanceLoad')}
                  </Button>
                  <Button variant="secondary" size="sm" icon="folder" className="flex-1">
                    {t('supervisors.viewProtocols')}
                  </Button>
                </div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t text-[11px] text-ink-subtle" style={{ borderColor: 'var(--color-border)' }}>
                  <button className="flex items-center gap-1 font-semibold text-ink-muted">
                    <Icon name="fact_check" size={13} />
                    {t('supervisors.auditLog')}
                  </button>
                  <span>{sup.lastActivity}</span>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <Thead>
              <Th>ID</Th>
              <Th>{t('supervisors.title')}</Th>
              <Th>{t('dashboard.department')}</Th>
              <Th align="end">{t('supervisors.utilized')}</Th>
              <Th align="end">{t('supervisors.capSlots')}</Th>
              <Th align="end">{t('supervisors.assigned')}</Th>
              <Th align="end">{t('supervisors.activeStudies')}</Th>
              <Th align="end">{t('dashboard.actions')}</Th>
            </Thead>
            <tbody>
              {filtered.map((sup) => {
                const dept = departments.find((d) => d.id === sup.departmentId);
                return (
                  <Tr key={sup.id}>
                    <Td mono className="text-primary font-semibold">{sup.id}</Td>
                    <Td>
                      <p className="font-semibold text-ink">{sup.name}</p>
                      <p className="text-[11.5px] text-ink-muted">{sup.title}</p>
                    </Td>
                    <Td>{dept?.name}</Td>
                    <Td align="end">
                      <Badge tone={BAND_TONE[sup.band]}>{sup.utilizationPct}%</Badge>
                    </Td>
                    <Td align="end" mono>{sup.capSlots}</Td>
                    <Td align="end" mono>{sup.assigned}</Td>
                    <Td align="end" mono>{sup.activeStudies}</Td>
                    <Td align="end">
                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => rebalanceSupervisor(sup.id, -3)}
                      >
                        {t('supervisors.rebalanceLoad')}
                      </button>
                    </Td>
                  </Tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      <ResearcherProfileDrawer open={!!drawerResearcher} onClose={() => setDrawerResearcher(null)} researcherId={drawerResearcher} />
    </div>
  );
}

function FilterChip({ active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      className="shrink-0 h-8 px-3 rounded-md text-[12.5px] font-semibold whitespace-nowrap transition-colors"
      style={{
        backgroundColor: active ? 'var(--color-primary)' : 'var(--color-surface-high)',
        color: active ? '#fff' : 'var(--color-text-secondary)',
      }}
    >
      {label}
    </button>
  );
}
