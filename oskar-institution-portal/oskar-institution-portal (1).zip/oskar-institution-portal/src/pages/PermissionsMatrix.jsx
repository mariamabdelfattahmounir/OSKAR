import { useState } from 'react';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Card, SectionHeader } from '../ui/Card';
import { Table, Thead, Th, Tr, Td } from '../ui/Table';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';

const ACTIONS = ['view', 'edit', 'approve', 'export'];

export default function PermissionsMatrix() {
  const { t } = useI18n();
  const { subAdmins, permissionModules, togglePermission, addSubAdmin } = useInstitutionData();
  const [expanded, setExpanded] = useState(subAdmins[0]?.id);
  const [dpaState, setDpaState] = useState('idle'); // idle | generating | ready
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminRole, setNewAdminRole] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const generateDpa = () => {
    setDpaState('generating');
    setTimeout(() => setDpaState('ready'), 1400);
  };

  const submitAddAdmin = (e) => {
    e.preventDefault();
    if (!newAdminName.trim() || !newAdminRole.trim()) return;
    addSubAdmin(newAdminName.trim(), newAdminRole.trim());
    setNewAdminName('');
    setNewAdminRole('');
    setShowAddForm(false);
  };

  return (
    <div className="flex flex-col gap-6">
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="font-heading text-[19px] font-bold text-ink">{t('permissions.title')}</h1>
            <p className="mt-1 text-[12.5px] text-ink-muted max-w-xl">{t('permissions.subtitle')}</p>
          </div>
          <Button variant="primary" size="md" icon="person_add" onClick={() => setShowAddForm((v) => !v)}>
            {t('permissions.addSubAdmin')}
          </Button>
        </div>

        {showAddForm && (
          <form onSubmit={submitAddAdmin} className="mt-4 pt-4 border-t flex flex-col sm:flex-row gap-3" style={{ borderColor: 'var(--color-border)' }}>
            <input
              className="input-field flex-1"
              placeholder="Full name"
              value={newAdminName}
              onChange={(e) => setNewAdminName(e.target.value)}
              required
            />
            <input
              className="input-field flex-1"
              placeholder="Role / title"
              value={newAdminRole}
              onChange={(e) => setNewAdminRole(e.target.value)}
              required
            />
            <Button type="submit" variant="primary" size="md" icon="check">
              {t('common.save')}
            </Button>
          </form>
        )}
      </Card>

      {subAdmins.map((admin) => {
        const isOpen = expanded === admin.id;
        return (
          <Card key={admin.id} className="overflow-hidden">
            <button
              className="w-full flex items-center justify-between gap-3 p-4"
              onClick={() => setExpanded(isOpen ? null : admin.id)}
            >
              <div className="flex items-center gap-3 text-left">
                <span
                  className="flex items-center justify-center w-9 h-9 rounded-full text-[12px] font-bold text-white shrink-0"
                  style={{ backgroundColor: 'var(--color-primary)' }}
                >
                  {admin.name.replace(/^(Dr\.|Mr\.|Ms\.|Prof\.)\s*/, '').split(' ').slice(0, 2).map((p) => p[0]).join('')}
                </span>
                <div>
                  <p className="font-semibold text-[13.5px] text-ink">{admin.name}</p>
                  <p className="text-[12px] text-ink-muted">{admin.role}</p>
                </div>
              </div>
              <Icon name={isOpen ? 'expand_less' : 'expand_more'} size={20} className="text-ink-muted" />
            </button>
            {isOpen && (
              <Table>
                <Thead>
                  <Th>{t('permissions.module')}</Th>
                  {ACTIONS.map((a) => (
                    <Th key={a} align="center">
                      {t(`permissions.${a}`)}
                    </Th>
                  ))}
                </Thead>
                <tbody>
                  {permissionModules.map((mod) => (
                    <Tr key={mod}>
                      <Td className="font-medium">{mod}</Td>
                      {ACTIONS.map((a) => (
                        <Td key={a} align="center">
                          <input
                            type="checkbox"
                            checked={!!admin.permissions[mod]?.[a]}
                            onChange={() => togglePermission(admin.id, mod, a)}
                            className="w-4 h-4 accent-[var(--color-primary)]"
                          />
                        </Td>
                      ))}
                    </Tr>
                  ))}
                </tbody>
              </Table>
            )}
          </Card>
        );
      })}

      <Card className="p-5">
        <SectionHeader title={t('permissions.dpaTitle')} icon="description" />
        <p className="text-[12.5px] text-ink-muted leading-relaxed max-w-2xl mb-4">{t('permissions.dpaNote')}</p>
        <div className="flex items-center gap-3">
          <Button
            variant="primary"
            size="md"
            icon={dpaState === 'ready' ? 'download' : 'picture_as_pdf'}
            loading={dpaState === 'generating'}
            onClick={dpaState === 'ready' ? () => setDpaState('idle') : generateDpa}
          >
            {dpaState === 'generating' ? t('permissions.generating') : dpaState === 'ready' ? t('common.download') : t('permissions.generate')}
          </Button>
          {dpaState === 'ready' && (
            <Badge tone="success">
              <Icon name="check_circle" size={12} />
              {t('permissions.ready')}
            </Badge>
          )}
        </div>
      </Card>
    </div>
  );
}
