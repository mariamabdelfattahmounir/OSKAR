import { Link } from 'react-router-dom';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { useI18n } from '../i18n/I18nContext';

export default function NotFound() {
  const { t } = useI18n();
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 gap-4">
      <Icon name="search_off" size={48} className="text-ink-subtle" />
      <h1 className="font-heading text-[20px] font-bold text-ink">404 — Node Not Found</h1>
      <p className="text-[13px] text-ink-muted max-w-md">
        This institutional route does not exist or you lack the IRB-scoped permission to view it.
      </p>
      <Link to="/">
        <Button variant="primary" size="md" icon="home">
          {t('nav.overview')}
        </Button>
      </Link>
    </div>
  );
}
