// OSKAR MedStat — Institutional Portal mock data.
// Models the System Design entity hierarchy:
//   Institution -> College -> Department -> Supervisor -> Researcher -> Study
// This stands in for the real institutional API and is consumed exclusively
// through src/context/InstitutionDataContext.jsx so it can be swapped for a
// live REST/GraphQL client without touching feature components.

export const institution = {
  id: 'INST-000001',
  name: 'University X',
  shortCode: 'INST-000001',
  domain: '@universityx.edu',
  domainVerified: true,
  irbNumber: 'IRB00012489',
  irbRegistered: true,
  description:
    'Primary academic health center tenant node. Managing clinical, translational, and observational multi-site trials under US 45 CFR 46 and GCP E6(R2) institutional governance framework.',
  tier: 'Tier-4 PHI Restricted Node',
  cluster: 'ME-CENTRAL-1',
  officer: {
    name: 'Dr. Sarah Al-Mansour',
    title: 'Chief Institutional Compliance Officer',
    avatar: 'SM',
    email: 'sarah.almansour@universityx.edu',
  },
};

export const colleges = [
  { id: 'COL-01', name: 'College of Medicine' },
  { id: 'COL-02', name: 'College of Dentistry' },
];

export const departments = [
  { id: 'DEPT-CARD', collegeId: 'COL-01', name: 'Cardiology', researchers: 112 },
  { id: 'DEPT-ONC', collegeId: 'COL-01', name: 'Oncology', researchers: 89 },
  { id: 'DEPT-NEURO', collegeId: 'COL-01', name: 'Neurology', researchers: 74 },
  { id: 'DEPT-PED', collegeId: 'COL-01', name: 'Pediatrics', researchers: 68 },
  { id: 'DEPT-SURG', collegeId: 'COL-01', name: 'Surgery', researchers: 55 },
  { id: 'DEPT-PATH', collegeId: 'COL-02', name: 'Pathology', researchers: 57 },
];

export const departmentColorMap = {
  'DEPT-CARD': '#00a896',
  'DEPT-ONC': '#0f172a',
  'DEPT-NEURO': '#df7a59',
  'DEPT-PED': '#38bdf8',
  'DEPT-SURG': '#9a4528',
  'DEPT-PATH': '#64748b',
};

export const dashboardMetrics = {
  totalUsers: { value: 462, deltaLabel: '+14/mo', trend: [12, 18, 14, 22, 26, 24, 30, 28, 33, 31, 36, 34] },
  supervisors: { value: 24, activeDepts: 8 },
  researchers: { value: 438, deltaLabel: '+3.2%', trend: [8, 10, 9, 14, 16, 15, 19, 18, 22, 21, 25, 24] },
  totalStudies: { value: 87, cumulative: true },
  activeStudies: { value: 42, multicenter: 28, enrolling: 28, analysis: 14 },
  pendingRequests: { value: 31, urgent: 12 },
  supervisorCapacity: 82,
  facultyCount: 24,
  fellowCount: 438,
};

export const activityFeed = [
  {
    id: 'ACT-1',
    kind: 'affiliation',
    actor: 'Dr. Rayan Al-Ghamdi',
    role: 'Fellow · Dept of Oncology',
    text: 'requested verified supervisor link to Prof. K. Jensen.',
    time: '4m ago',
    actions: ['authorize', 'inspect'],
  },
  {
    id: 'ACT-2',
    kind: 'signoff',
    actor: 'Prof. Eleanor Vance',
    text: 'approved Cohort Inclusion Matrix for Multicenter Cardio-Stent Study.',
    meta: 'SHA-256: 8f4a...2c90 (Part 11 Sig)',
    time: '22m ago',
  },
  {
    id: 'ACT-3',
    kind: 'audit',
    actor: 'HIPAA Security Audit Attestation',
    text: 'Annual Safe Harbor compliance recertification confirmed for University X node.',
    time: '2h ago',
  },
];

export const priorityProtocols = [
  {
    irbId: 'IRB-2023-0894',
    title: 'Novel SGLT2 Inhibitor in Heart Failure with Preserved Ejection Fraction',
    supervisor: 'Prof. Tariq Mansoor, MD, PhD',
    departmentId: 'DEPT-CARD',
    cohortN: 1420,
    node: 'GCP-Validated',
    nodeState: 'success',
  },
  {
    irbId: 'IRB-2024-0112',
    title: 'Targeted Neoantigen mRNA Immunotherapy in Advanced Pancreatic Carcinoma',
    supervisor: 'Prof. Karen Jensen, MD',
    departmentId: 'DEPT-ONC',
    cohortN: 380,
    node: 'GCP-Validated',
    nodeState: 'success',
  },
  {
    irbId: 'IRB-2024-0348',
    title: 'Pre-symptomatic Biomarker Mapping in Familial Amyotrophic Lateral Sclerosis',
    supervisor: 'Prof. David Sterling, FACP',
    departmentId: 'DEPT-NEURO',
    cohortN: 610,
    node: 'Amendment Pending',
    nodeState: 'warning',
  },
];

// ---------------------------------------------------------------------------
// Domain User Discovery / Matching Engine
// ---------------------------------------------------------------------------

export const matchCandidates = [
  {
    id: 'CAND-01',
    name: 'Dr. Tariq Al-Hashimi',
    title: 'Associate Professor, Invasive Cardiology',
    department: 'Division of Cardiology · Lab #304',
    email: 't.alhashimi@universityx.edu',
    orcid: '0000-0002-8819-0194',
    pmid: '38291042',
    evidence: '14 co-authored university papers detected',
    matchType: 'Verified ORCID Match',
    matchLevel: 'success',
    confidence: 98,
    ciLow: 95.8,
    ciHigh: 99.4,
    reliability: 'High Reliability',
    status: 'unlinked',
  },
  {
    id: 'CAND-02',
    name: 'Dr. Elena Rostova',
    title: 'Lead Biostatistician, Genomic Oncology',
    department: 'Center for Clinical Oncology',
    email: 'e.rostova@universityx.edu',
    orcid: '0000-0001-5502-3901',
    pmid: '39018441',
    evidence: '9 co-authored university papers detected',
    matchType: 'Verified Department Pub',
    matchLevel: 'success',
    confidence: 95,
    ciLow: 93.1,
    ciHigh: 97.2,
    reliability: 'High Reliability',
    status: 'unlinked',
  },
  {
    id: 'CAND-03',
    name: 'Dr. Zayd Mansour',
    title: 'Consultant Neurosurgeon & Fellow',
    department: 'Department of Neurology',
    email: 'z.mansour@universityx-hospital.org',
    orcid: '0000-0003-1022-7718',
    evidence: 'Dual affiliation: University Teaching Hospital & Faculty',
    matchType: 'Dual Affiliation',
    matchLevel: 'info',
    confidence: 84,
    ciLow: 79.4,
    ciHigh: 88.5,
    reliability: 'Verification Requisite',
    status: 'unlinked',
  },
  {
    id: 'CAND-04',
    name: 'Dr. Noura Al-Kindi',
    title: 'Postdoctoral Research Fellow',
    department: 'Biostatistics & Epidemiology',
    email: 'n.alkindi@alumni.universityx.edu',
    orcid: '0000-0004-9910-1823',
    evidence: 'Legacy/alumni token detected · No active 2025 IRB protocol',
    matchType: 'Review Needed',
    matchLevel: 'warning',
    confidence: 72,
    ciLow: 64.2,
    ciHigh: 78.0,
    reliability: 'Manual Confirm',
    status: 'unlinked',
  },
  {
    id: 'CAND-05',
    name: 'Dr. Hana Youssef',
    title: 'Clinical Research Fellow, Pediatric Endocrinology',
    department: 'Department of Pediatrics',
    email: 'h.youssef@universityx.edu',
    orcid: '0000-0002-4471-6620',
    pmid: '38812207',
    evidence: '6 co-authored university papers detected',
    matchType: 'Verified ORCID Match',
    matchLevel: 'success',
    confidence: 91,
    ciLow: 88.0,
    ciHigh: 94.1,
    reliability: 'High Reliability',
    status: 'unlinked',
  },
  {
    id: 'CAND-06',
    name: 'Dr. Omar Basha',
    title: 'Surgical Pathology Fellow',
    department: 'Department of Pathology',
    email: 'o.basha@universityx.edu',
    orcid: '0000-0001-7723-4482',
    evidence: 'Legacy alumni footprint · pending sub-department confirmation',
    matchType: 'Review Needed',
    matchLevel: 'warning',
    confidence: 68,
    ciLow: 59.5,
    ciHigh: 75.0,
    reliability: 'Manual Confirm',
    status: 'unlinked',
  },
];

export const discoveryStats = {
  candidatesIdentified: 38,
  highConfidence: 29,
  discoveredPapers: 412,
  pendingManualReview: 4,
};

// ---------------------------------------------------------------------------
// Supervisors / Faculty workload
// ---------------------------------------------------------------------------

export const supervisors = [
  {
    id: 'SUP-88210',
    name: 'Prof. Dr. Khalid Al-Otaibi',
    title: 'MD, PhD · Senior Electrophysiologist',
    departmentId: 'DEPT-CARD',
    capSlots: 24,
    assigned: 22,
    utilizationPct: 92,
    band: 'high',
    activeResearchers: 22,
    activeStudies: 6,
    note: '+3 from Dec cycle',
    studiesNote: '3 Multi-Center Phase III',
    lastActivity: '2h ago',
  },
  {
    id: 'SUP-88244',
    name: 'Dr. Fatima Al-Zahrani',
    title: 'MBBS, FRCP · Clinical Oncologist',
    departmentId: 'DEPT-ONC',
    capSlots: 20,
    assigned: 15,
    utilizationPct: 72,
    band: 'moderate',
    activeResearchers: 15,
    activeStudies: 4,
    note: 'Balanced allocation',
    studiesNote: '1 Phase II Lymphoma',
    lastActivity: 'Reviewed today',
  },
  {
    id: 'SUP-88299',
    name: 'Prof. Marcus Vance',
    title: 'MD, DSc · Neurodegenerative Disorders',
    departmentId: 'DEPT-NEURO',
    capSlots: 25,
    assigned: 12,
    utilizationPct: 48,
    band: 'available',
    activeResearchers: 12,
    activeStudies: 3,
    note: 'Ready for intake',
    studiesNote: '3 Active Grants',
    lastActivity: 'Updated yesterday',
  },
  {
    id: 'SUP-88312',
    name: 'Dr. Tariq Al-Hashimi',
    title: 'MD, FAAP · Pediatric Genetics',
    departmentId: 'DEPT-PED',
    capSlots: 20,
    assigned: 19,
    utilizationPct: 96,
    band: 'high',
    activeResearchers: 19,
    activeStudies: 7,
    note: 'IRB escalation active',
    studiesNote: '4 Rare Disease Registries',
    lastActivity: 'Logged 14m ago',
  },
  {
    id: 'SUP-88401',
    name: 'Dr. Leena Sommer',
    title: 'MD, FRCPath · Surgical Pathology',
    departmentId: 'DEPT-PATH',
    capSlots: 22,
    assigned: 15,
    utilizationPct: 68,
    band: 'moderate',
    activeResearchers: 15,
    activeStudies: 5,
    note: 'Normal cadence',
    studiesNote: '2 Histology Cohorts',
    lastActivity: 'Reviewed today',
  },
  {
    id: 'SUP-88102',
    name: 'Prof. Faisal Al-Sabah',
    title: 'MD, FRCS · Cardiothoracic Surgery',
    departmentId: 'DEPT-SURG',
    capSlots: 20,
    assigned: 10,
    utilizationPct: 50,
    band: 'available',
    activeResearchers: 10,
    activeStudies: 2,
    note: '10 slots available',
    studiesNote: '2 Valve Sparing Trials',
    lastActivity: '3 days ago',
  },
];

export const supervisorWorkloadSummary = {
  ratio: '18.25:1',
  targetThreshold: '20:1',
  inSafeBand: true,
  highCapacityCount: 4,
  highCapacityPctOfCorps: 16.6,
  irbActiveProtocols: 86,
  irbDelta: '+7 this term',
  traineesAudited: 438,
  traineesAuditedPct: 100,
  guideline: { availableMax: 60, moderateMax: 85 },
  guidelineCounts: { available: 8, moderate: 12, high: 4 },
  universityCap: 25,
};

// ---------------------------------------------------------------------------
// Researchers (drill-down profiles)
// ---------------------------------------------------------------------------

export const researchers = [
  {
    id: 'RES-3301',
    name: 'Dr. Layla Mahmoud',
    title: 'Senior Oncology Fellow',
    departmentId: 'DEPT-ONC',
    supervisorId: 'SUP-88244',
    email: 'l.mahmoud@universityx.edu',
    orcid: '0000-0002-1147-8820',
    status: 'active',
    joined: 'Jan 2023',
    publications: 11,
    activeStudies: ['IRB-2024-0112', 'IRB-2023-0761'],
  },
  {
    id: 'RES-3302',
    name: 'Prof. Tariq K. Fakhoury',
    title: 'Lead Genomic Epidemiologist',
    departmentId: 'DEPT-CARD',
    supervisorId: 'SUP-88210',
    email: 't.fakhoury@universityx.edu',
    orcid: '0000-0001-6620-4471',
    status: 'active',
    joined: 'Aug 2021',
    publications: 24,
    activeStudies: ['IRB-2023-0894'],
  },
  {
    id: 'RES-3303',
    name: 'Dr. Noura S. Al-Aziz',
    title: 'Pediatric Neurologist & Co-Investigator',
    departmentId: 'DEPT-PED',
    supervisorId: 'SUP-88312',
    email: 'n.alaziz@universityx.edu',
    orcid: '0000-0004-3390-1187',
    status: 'active',
    joined: 'Mar 2024',
    publications: 5,
    activeStudies: ['IRB-2024-0348'],
  },
];

// ---------------------------------------------------------------------------
// Connection Requests (two-way consent)
// ---------------------------------------------------------------------------

export const connectionRequests = [
  {
    id: 'REQ-2024-0982',
    investigator: 'Dr. Layla Mahmoud',
    role: 'Senior Oncology Fellow',
    initials: 'LM',
    department: 'Dept. of Medical Oncology & Therapeutics',
    branch: 'University X Main Teaching Hospital',
    direction: 'incoming',
    proofs: ['Verified ID', 'Dept Sign-off', 'SSO Token'],
    proofState: 'complete',
    submitted: 'Submitted 2h ago',
    sla: '5d left to respond',
    slaUrgent: false,
    status: 'pending',
  },
  {
    id: 'REQ-2024-0979',
    investigator: 'Prof. Tariq K. Fakhoury',
    role: 'Lead Genomic Epidemiologist',
    initials: 'FK',
    department: 'Center for Precision Medicine & Biostats',
    branch: 'Cardiovascular Research Center (North Annex)',
    direction: 'incoming',
    proofs: ['Verified ID', 'Dept Sign-off', 'Part-11 Signed'],
    proofState: 'complete',
    submitted: 'Approved 4h ago',
    sla: 'Dual-Key Bound',
    slaUrgent: false,
    status: 'accepted',
  },
  {
    id: 'REQ-2024-0975',
    investigator: 'Dr. Noura S. Al-Aziz',
    role: 'Pediatric Neurologist & Co-Investigator',
    initials: 'NA',
    department: 'Neurodevelopmental Research Division',
    branch: 'Women & Children Clinical Institute',
    direction: 'outgoing',
    proofs: ['Institutional Seal', 'Pending Doctor Key'],
    proofState: 'partial',
    submitted: 'Dispatched yesterday',
    sla: '13d remaining',
    slaUrgent: false,
    status: 'pending',
  },
  {
    id: 'REQ-2024-0961',
    investigator: 'Dr. Walid R. Mansour',
    role: 'Adjunct Clinical Biostatistician',
    initials: 'WR',
    department: 'Independent Contractual Research Unit',
    branch: 'External Affiliate Network',
    direction: 'incoming',
    proofs: ['Unverified Institution Key'],
    proofState: 'failed',
    submitted: 'Closed Oct 24',
    sla: 'Archived to log',
    slaUrgent: false,
    status: 'declined',
    declineReason: 'IRB Scope Mismatch',
  },
  {
    id: 'REQ-2024-0955',
    investigator: 'Dr. Hisham M. Abdel-Raheem',
    role: 'Consultant Pulmonology & Critical Care',
    initials: 'HA',
    department: 'Department of Respiratory Therapeutics',
    branch: 'University Teaching Hospital (ICU Annex)',
    direction: 'incoming',
    proofs: ['Verified ID', 'Sign-off Incomplete'],
    proofState: 'partial',
    submitted: 'Submitted 18h ago',
    sla: '6d left',
    slaUrgent: false,
    status: 'pending',
  },
];

export const connectionRequestSummary = {
  incomingPending: 19,
  incomingSlaNote: 'SLA < 48h (3 critical)',
  outgoingDispatched: 12,
  outgoingNote: '8 pending sign-off',
  dualConsentSealed: 148,
  dualConsentPeriod: '30-day total',
  credentialScorePct: 97.8,
};

// ---------------------------------------------------------------------------
// Studies & Governance
// ---------------------------------------------------------------------------

export const studyProductivity = {
  activeClinicalStudies: { value: 42, delta: '+6 QoQ', note: '28 Phase I-III' },
  completedStudies: { value: 45, note: '14 Observational' },
  statisticalExportVolumes: { value: '1,840', unit: 'GB De-ID Clean', delta: '12.4 GB' },
  publications: { value: 118, note: 'Avg IF: 6.84' },
};

export const departmentOutputSeries = {
  months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  oncology: [8, 10, 7, 12, 14, 9, 11, 13, 10, 15, 12, 18],
  cardiology: [6, 8, 9, 11, 20, 10, 9, 12, 30, 14, 16, 22],
  neurology: [4, 5, 6, 5, 8, 6, 7, 6, 8, 7, 9, 10],
};

export const statisticalToolDistribution = [
  { name: 'IBM SPSS Statistics (.sav)', pct: 58 },
  { name: 'R Studio / Bioconductor', pct: 24 },
  { name: 'SAS Enterprise Clinical', pct: 12 },
  { name: 'Python BioMed (SciPy/Lifelines)', pct: 6 },
];

export const complianceVerification = {
  pct: 99.4,
  label: '424/426 protocol sign-offs verified compliant with zero audit infractions logged this cycle.',
};

export const oversightStudies = [
  {
    protocolId: 'IRB-2024-00192',
    title: 'Targeted Tyrosine Kinase Inhibitors in Refractory Lung Adenocarcinoma',
    phase: 'Phase III Trial',
    protocolRef: 'NCT04928172',
    exp: '2025-11-30',
    piInitials: 'MK',
    pi: 'Prof. Marcus Kelly, MD',
    faculty: 'Dept. of Thoracic Oncology',
    cohortN: 450,
    dataState: 'De-Identified Agg',
  },
  {
    protocolId: 'IRB-2024-00215',
    title: 'Multi-Omic Biomarker Discovery in Pediatric Neuroblastoma Cohorts',
    phase: 'Observational',
    protocolRef: 'Protocol OMIC-88',
    exp: '2026-03-15',
    piInitials: 'EL',
    pi: 'Dr. Elena Rostova, PhD',
    faculty: 'Center for Genomic Medicine',
    cohortN: 210,
    dataState: 'De-Identified Agg',
  },
  {
    protocolId: 'IRB-2023-01088',
    title: 'Comparative Effectiveness of SGLT2 Inhibitors vs GLP-1 RAs in Heart Failure with Preserved Ejection Fraction',
    phase: 'Phase IV Post-Market',
    protocolRef: 'NCT05112093',
    exp: '2025-08-12',
    piInitials: 'TA',
    pi: 'Dr. Tariq Al-Hassan, MD',
    faculty: 'Division of Cardiology',
    cohortN: 1120,
    dataState: 'De-Identified Agg',
  },
  {
    protocolId: 'IRB-2024-00304',
    title: 'AI-Guided Contrast CT Segmentation in Acute Ischemic Stroke Triage',
    phase: 'Medical Device · SaMD',
    protocolRef: 'FDA 510(k) Validation',
    exp: '2025-10-01',
    piInitials: 'CH',
    pi: 'Prof. Claire Hoffman, PhD',
    faculty: 'Dept. of Radiology & AI',
    cohortN: 340,
    dataState: 'De-Identified Agg',
  },
];

// ---------------------------------------------------------------------------
// Permissions matrix & sub-admins
// ---------------------------------------------------------------------------

export const permissionModules = [
  'Institutional Overview',
  'Domain User Discovery',
  'Supervisor Workloads',
  'Connection Requests',
  'Studies & Governance',
  'Billing & Contracts',
];

export const subAdmins = [
  {
    id: 'ADMIN-01',
    name: 'Dr. Sarah Al-Mansour',
    role: 'Chief Institutional Compliance Officer',
    permissions: {
      'Institutional Overview': { view: true, edit: true, approve: true, export: true },
      'Domain User Discovery': { view: true, edit: true, approve: true, export: true },
      'Supervisor Workloads': { view: true, edit: true, approve: true, export: true },
      'Connection Requests': { view: true, edit: true, approve: true, export: true },
      'Studies & Governance': { view: true, edit: true, approve: true, export: true },
      'Billing & Contracts': { view: true, edit: true, approve: true, export: true },
    },
  },
  {
    id: 'ADMIN-02',
    name: 'Mr. Adham Naser',
    role: 'IRB Registry Coordinator',
    permissions: {
      'Institutional Overview': { view: true, edit: false, approve: false, export: true },
      'Domain User Discovery': { view: true, edit: true, approve: false, export: true },
      'Supervisor Workloads': { view: true, edit: false, approve: false, export: false },
      'Connection Requests': { view: true, edit: true, approve: true, export: true },
      'Studies & Governance': { view: true, edit: false, approve: true, export: true },
      'Billing & Contracts': { view: false, edit: false, approve: false, export: false },
    },
  },
  {
    id: 'ADMIN-03',
    name: 'Ms. Dana Al-Farsi',
    role: 'Faculty Affairs Analyst',
    permissions: {
      'Institutional Overview': { view: true, edit: false, approve: false, export: false },
      'Domain User Discovery': { view: true, edit: false, approve: false, export: false },
      'Supervisor Workloads': { view: true, edit: true, approve: false, export: true },
      'Connection Requests': { view: true, edit: false, approve: false, export: false },
      'Studies & Governance': { view: false, edit: false, approve: false, export: false },
      'Billing & Contracts': { view: false, edit: false, approve: false, export: false },
    },
  },
];
