import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import translations from './translations';

const I18nContext = createContext(null);

const STORAGE_KEY = 'oskar_lang';

function resolve(dict, path) {
  return path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), dict);
}

export function I18nProvider({ children }) {
  const [locale, setLocaleState] = useState(() => {
    if (typeof window === 'undefined') return 'en';
    return localStorage.getItem(STORAGE_KEY) || 'en';
  });

  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    const html = document.documentElement;
    html.setAttribute('lang', locale);
    html.setAttribute('dir', dir);
    localStorage.setItem(STORAGE_KEY, locale);
  }, [locale, dir]);

  const setLocale = useCallback((next) => {
    setLocaleState(next);
  }, []);

  const toggleLocale = useCallback(() => {
    setLocaleState((prev) => (prev === 'en' ? 'ar' : 'en'));
  }, []);

  const t = useCallback(
    (key, fallback) => {
      const dict = translations[locale] || translations.en;
      const value = resolve(dict, key);
      if (value !== undefined) return value;
      const enValue = resolve(translations.en, key);
      return enValue !== undefined ? enValue : fallback || key;
    },
    [locale]
  );

  const value = useMemo(
    () => ({ locale, dir, setLocale, toggleLocale, t, isRtl: dir === 'rtl' }),
    [locale, dir, setLocale, toggleLocale, t]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
