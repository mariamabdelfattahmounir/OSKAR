import { useEffect, useRef, useState } from 'react';

/**
 * Simulates a live secure-medical-environment telemetry cycle for the
 * compliance status banner: a session countdown, rotating latency reading,
 * and a synced/syncing pulse — all derived client-side (no network calls)
 * so the ticker keeps "breathing" for as long as the portal is open.
 */
export function useComplianceTelemetry() {
  const [secondsLeft, setSecondsLeft] = useState(43 * 60 + 15); // 43:15 like reference screen
  const [latencyMs, setLatencyMs] = useState(24);
  const [syncPulse, setSyncPulse] = useState(true);
  const tickRef = useRef(0);

  useEffect(() => {
    const interval = setInterval(() => {
      tickRef.current += 1;
      setSecondsLeft((prev) => (prev <= 1 ? 45 * 60 : prev - 1));

      // Jitter the latency reading between 18-40ms every ~3s for a "live" feel.
      if (tickRef.current % 3 === 0) {
        setLatencyMs(18 + Math.round(Math.random() * 22));
        setSyncPulse((prev) => !prev);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const sessionExpiry = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return { sessionExpiry, latencyMs, syncPulse };
}
