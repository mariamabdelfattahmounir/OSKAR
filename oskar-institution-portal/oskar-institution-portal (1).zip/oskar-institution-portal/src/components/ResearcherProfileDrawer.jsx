import Drawer from '../ui/Drawer';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';
import { departments } from '../data/mockData';

/**
 * Interactive sliding panel for individual researcher drill-downs. Can be
 * opened from the dashboard activity feed, the Supervisors directory (per
 * researcher chip), or the Domain Discovery table once a candidate has been
 * linked.
 */
export default function ResearcherProfileDrawer({ open, onClose, researcherId }) {
  const { t } = useI18n();
  const { researchers, supervisors } = useInstitutionData();

  const researcher = researchers.find((r) => r.id === researcherId) || researchers[0];
  const supervisor = supervisors.find((s) => s.id === researcher?.supervisorId);
  const department = departments.find((d) => d.id === researcher?.departmentId);

  if (!researcher) return null;

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={t('researcherDrawer.title')}
      subtitle={researcher.name}
      footer={
        <>
          <Button variant="secondary" size="md" onClick={onClose}>
            {t('common.close')}
          </Button>
          <Button variant="primary" size="md" icon="open_in_new">
            {t('researcherDrawer.viewFullRecord')}
          </Button>
        </>
      }
    >
      <div className="flex items-center gap-3 mb-5">
        <span
          className="flex items-center justify-center w-14 h-14 rounded-full text-[16px] font-bold text-white shrink-0"
          style={{ backgroundColor: 'var(--color-primary)' }}
        >
          {researcher.name
            .replace(/^(Dr\.|Prof\.)\s*/, '')
            .split(' ')
            .slice(0, 2)
            .map((p) => p[0])
            .join('')}
        </span>
        <div>
          <h3 className="font-semibold text-[15px] text-ink">{researcher.name}</h3>
          <p className="text-[12.5px] text-ink-muted">{researcher.title}</p>
          <Badge tone={researcher.status === 'active' ? 'success' : 'neutral'} className="mt-1">
            {t(`common.${researcher.status}`)}
          </Badge>
        </div>
      </div>

      <dl className="grid grid-cols-1 gap-3 text-[13px]">
        <Row label={t('researcherDrawer.department')} value={department?.name} icon="apartment" />
        <Row label={t('researcherDrawer.supervisor')} value={supervisor?.name} icon="school" />
        <Row label={t('researcherDrawer.email')} value={researcher.email} icon="mail" mono />
        <Row label={t('researcherDrawer.orcid')} value={researcher.orcid} icon="fingerprint" mono />
        <Row label={t('researcherDrawer.joined')} value={researcher.joined} icon="event" />
        <Row label={t('researcherDrawer.publications')} value={researcher.publications} icon="menu_book" />
      </dl>

      <div className="mt-5 pt-4 border-t" style={{ borderColor: 'var(--color-border)' }}>
        <h4 className="text-[12px] font-bold uppercase tracking-wide text-ink-subtle mb-2">
          {t('researcherDrawer.activeStudiesList')}
        </h4>
        <ul className="flex flex-col gap-2">
          {researcher.activeStudies.map((irb) => (
            <li
              key={irb}
              className="flex items-center justify-between px-3 py-2 rounded-md text-[12.5px]"
              style={{ backgroundColor: 'var(--color-surface-low)' }}
            >
              <span className="font-data font-semibold text-primary">{irb}</span>
              <Icon name="chevron_right" size={16} className="text-ink-muted" flip />
            </li>
          ))}
        </ul>
      </div>
    </Drawer>
  );
}

function Row({ label, value, icon, mono }) {
  return (
    <div className="flex items-start gap-3">
      <span
        className="flex items-center justify-center w-8 h-8 rounded-md shrink-0"
        style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}
      >
        <Icon name={icon} size={16} />
      </span>
      <div className="min-w-0">
        <dt className="text-[11px] text-ink-subtle font-semibold uppercase tracking-wide">{label}</dt>
        <dd className={`text-ink ${mono ? 'font-data text-[12px]' : 'text-[13px]'} truncate`}>{value}</dd>
      </div>
    </div>
  );
}
