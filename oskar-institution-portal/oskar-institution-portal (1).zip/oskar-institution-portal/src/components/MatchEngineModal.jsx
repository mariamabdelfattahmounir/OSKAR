import Modal from '../ui/Modal';
import Icon from '../ui/Icon';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { ConfidenceMeter } from '../ui/Meters';
import { useI18n } from '../i18n/I18nContext';

/**
 * MatchEngineModal — shown when an institutional officer inspects the
 * evidence trail behind a discovered candidate ("Proof") or confirms a
 * single cryptographically-consented connection request.
 */
export default function MatchEngineModal({ candidate, mode, onClose, onConnect, connecting }) {
  const { t } = useI18n();
  if (!candidate) return null;

  const isProof = mode === 'proof';

  return (
    <Modal
      open={!!candidate}
      onClose={onClose}
      title={isProof ? `${t('discovery.proof')} — ${candidate.name}` : `${t('discovery.connect')} — ${candidate.name}`}
      subtitle={candidate.title}
      size="md"
      footer={
        <>
          <Button variant="secondary" size="md" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          {!isProof && (
            <Button variant="primary" size="md" icon="link" loading={connecting} onClick={() => onConnect(candidate.id)}>
              {t('discovery.connect')}
            </Button>
          )}
        </>
      }
    >
      <div className="flex items-center gap-3 mb-4">
        <span
          className="flex items-center justify-center w-11 h-11 rounded-full text-[14px] font-bold text-white shrink-0"
          style={{ backgroundColor: 'var(--color-primary)' }}
        >
          {candidate.name
            .replace(/^(Dr\.|Prof\.)\s*/, '')
            .split(' ')
            .slice(0, 2)
            .map((p) => p[0])
            .join('')}
        </span>
        <div>
          <p className="font-semibold text-[14px] text-ink">{candidate.name}</p>
          <p className="text-[12.5px] text-ink-muted">{candidate.department}</p>
        </div>
        <Badge tone={candidate.matchLevel} className="ms-auto">
          {candidate.matchType}
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <InfoBox icon="mail" label="Email" value={candidate.email} mono />
        <InfoBox icon="fingerprint" label="ORCID" value={candidate.orcid} mono />
        {candidate.pmid && <InfoBox icon="menu_book" label="PubMed ID" value={candidate.pmid} mono />}
        <InfoBox icon="percent" label={t('discovery.matchScore')} value={`${candidate.confidence}%`} />
      </div>

      <div className="rounded-card p-3 mb-4" style={{ backgroundColor: 'var(--color-surface-low)' }}>
        <p className="text-[11px] font-bold uppercase tracking-wide text-ink-subtle mb-2">
          {t('discovery.discoveredEvidence')}
        </p>
        <p className="text-[12.5px] text-ink flex items-start gap-2">
          <Icon name="description" size={16} className="text-primary shrink-0 mt-0.5" />
          {candidate.evidence}
        </p>
        <div className="mt-3">
          <ConfidenceMeter confidence={candidate.confidence} ciLow={candidate.ciLow} ciHigh={candidate.ciHigh} tone={candidate.matchLevel} />
        </div>
      </div>

      <div
        className="flex items-start gap-2 rounded-card p-3 text-[12px] leading-relaxed"
        style={{ backgroundColor: 'var(--color-info-bg)', color: 'var(--color-text-secondary)' }}
      >
        <Icon name="shield_lock" size={16} style={{ color: 'var(--color-info)' }} className="shrink-0 mt-0.5" />
        {t('discovery.consentNote')}
      </div>
    </Modal>
  );
}

function InfoBox({ icon, label, value, mono }) {
  return (
    <div className="rounded-card border p-2.5" style={{ borderColor: 'var(--color-border)' }}>
      <p className="flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wide text-ink-subtle">
        <Icon name={icon} size={13} />
        {label}
      </p>
      <p className={`mt-0.5 text-ink truncate ${mono ? 'font-data text-[12px]' : 'text-[13px]'}`}>{value}</p>
    </div>
  );
}
