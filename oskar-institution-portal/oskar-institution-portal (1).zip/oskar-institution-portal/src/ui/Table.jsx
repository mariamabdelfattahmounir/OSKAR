export function Table({ children, className = '' }) {
  return (
    <div className="overflow-x-auto rounded-card border" style={{ borderColor: 'var(--color-border)' }}>
      <table className={`w-full border-collapse text-[13px] ${className}`}>{children}</table>
    </div>
  );
}

export function Thead({ children }) {
  return (
    <thead>
      <tr
        className="text-[11px] font-bold uppercase tracking-wide text-ink-subtle"
        style={{ backgroundColor: 'var(--color-surface-low)' }}
      >
        {children}
      </tr>
    </thead>
  );
}

export function Th({ children, align = 'start', className = '' }) {
  const alignClass = align === 'end' ? 'text-end' : align === 'center' ? 'text-center' : 'text-start';
  return (
    <th
      className={`px-4 h-9 border-b font-semibold ${alignClass} ${className}`}
      style={{ borderColor: 'var(--color-border-subtle)' }}
    >
      {children}
    </th>
  );
}

export function Td({ children, align = 'start', className = '', mono = false }) {
  const alignClass = align === 'end' ? 'text-end' : align === 'center' ? 'text-center' : 'text-start';
  return (
    <td
      className={`px-4 py-3 align-middle border-b ${alignClass} ${mono ? 'font-data' : ''} ${className}`}
      style={{ borderColor: 'var(--color-border)' }}
    >
      {children}
    </td>
  );
}

export function Tr({ children, className = '', ...rest }) {
  return (
    <tr className={`transition-colors hover:bg-[var(--color-surface-low)] ${className}`} {...rest}>
      {children}
    </tr>
  );
}
