import { useEffect } from 'react';
import { createPortal } from 'react-dom';
import Icon from './Icon';
import { useI18n } from '../i18n/I18nContext';

export default function Drawer({ open, onClose, title, subtitle, children, footer }) {
  const { t, isRtl } = useI18n();

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  const sideClass = isRtl ? 'left-0' : 'right-0';
  const enterAnim = isRtl ? 'animate-[slideInLeft_0.25s_ease-out]' : 'animate-[slideInRight_0.25s_ease-out]';

  return createPortal(
    <div
      className="fixed inset-0 z-[100] flex"
      style={{ backgroundColor: 'var(--backdrop)' }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose?.();
      }}
    >
      <div
        className={`absolute top-0 ${sideClass} h-full w-full max-w-md flex flex-col border-s ${enterAnim}`}
        style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-modal)' }}
      >
        <div className="flex items-start justify-between gap-4 px-5 py-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <div>
            <h2 className="font-heading text-[15px] font-semibold text-ink">{title}</h2>
            {subtitle && <p className="mt-0.5 text-[12.5px] text-ink-muted">{subtitle}</p>}
          </div>
          <button className="btn btn-icon btn-outline shrink-0" onClick={onClose} aria-label={t('common.close')}>
            <Icon name="close" size={18} />
          </button>
        </div>
        <div className="px-5 py-4 overflow-y-auto flex-1">{children}</div>
        {footer && (
          <div
            className="flex items-center justify-end gap-3 px-5 py-4 border-t"
            style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-surface-low)' }}
          >
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}
