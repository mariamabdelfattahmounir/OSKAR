const TONE_STYLES = {
  success: { bg: 'var(--color-success-bg)', fg: 'var(--color-success)', dot: 'var(--color-success)' },
  warning: { bg: 'var(--color-warning-bg)', fg: 'var(--color-warning)', dot: 'var(--color-warning)' },
  info: { bg: 'var(--color-info-bg)', fg: 'var(--color-info)', dot: 'var(--color-info)' },
  danger: { bg: 'var(--color-danger-bg)', fg: 'var(--color-danger)', dot: 'var(--color-danger)' },
  audit: { bg: 'var(--color-audit-bg)', fg: 'var(--color-audit)', dot: 'var(--color-audit)' },
  neutral: { bg: 'var(--color-surface-high)', fg: 'var(--color-text-secondary)', dot: 'var(--color-text-muted)' },
};

export default function Badge({ tone = 'neutral', dot = true, pulse = false, children, className = '' }) {
  const style = TONE_STYLES[tone] || TONE_STYLES.neutral;
  return (
    <span
      className={`badge ${className}`}
      style={{ backgroundColor: style.bg, color: style.fg }}
    >
      {dot && (
        <span
          className={`badge-dot ${pulse ? 'animate-pulse-dot' : ''}`}
          style={{ backgroundColor: style.dot }}
        />
      )}
      {children}
    </span>
  );
}
