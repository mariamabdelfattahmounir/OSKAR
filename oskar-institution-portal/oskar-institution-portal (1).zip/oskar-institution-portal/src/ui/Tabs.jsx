export default function Tabs({ items, active, onChange, className = '' }) {
  return (
    <div className={`inline-flex items-center gap-1 p-1 rounded-md ${className}`} style={{ backgroundColor: 'var(--color-surface-high)' }}>
      {items.map((item) => {
        const isActive = item.value === active;
        return (
          <button
            key={item.value}
            onClick={() => onChange(item.value)}
            className="px-3 h-7 rounded text-[12.5px] font-semibold transition-colors"
            style={{
              backgroundColor: isActive ? 'var(--color-surface)' : 'transparent',
              color: isActive ? 'var(--color-primary)' : 'var(--color-text-secondary)',
              boxShadow: isActive ? '0 1px 2px rgba(15,23,42,0.08)' : 'none',
            }}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
}
