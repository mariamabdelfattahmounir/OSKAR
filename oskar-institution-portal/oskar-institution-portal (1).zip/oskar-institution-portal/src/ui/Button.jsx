import Icon from './Icon';

const VARIANT_CLASS = {
  primary: 'btn-primary',
  secondary: 'btn-secondary',
  outline: 'btn-outline',
  danger: 'btn-danger',
};

const SIZE_CLASS = {
  sm: 'btn-sm',
  md: 'btn-md',
  lg: 'btn-lg',
};

const ICON_SIZE = { sm: 16, md: 18, lg: 20 };

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  trailingIcon,
  iconOnly = false,
  loading = false,
  className = '',
  disabled,
  ...rest
}) {
  const iconSize = ICON_SIZE[size];
  return (
    <button
      className={`btn ${VARIANT_CLASS[variant]} ${SIZE_CLASS[size]} ${iconOnly ? 'btn-icon' : ''} ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? (
        <span
          className="inline-block animate-spin rounded-full border-2 border-current border-t-transparent"
          style={{ width: iconSize, height: iconSize }}
        />
      ) : (
        icon && <Icon name={icon} size={iconSize} />
      )}
      {!iconOnly && children}
      {trailingIcon && !loading && <Icon name={trailingIcon} size={iconSize} />}
    </button>
  );
}
