// Zero-emoji iconography contract (marieam/ICONOGRAPHY.md): Google Material
// Symbols Outlined exclusively. `flip` should only be set true for
// directional icons (arrow_forward, chevron_right...) per RTL_LTR.md.
export default function Icon({ name, size = 20, className = '', flip = false, filled = false }) {
  return (
    <span
      className={`material-symbols-outlined select-none leading-none ${flip ? 'icon-flip-rtl' : ''} ${className}`}
      style={{
        fontSize: size,
        width: size,
        height: size,
        fontVariationSettings: `'FILL' ${filled ? 1 : 0}, 'wght' 500, 'GRAD' 0, 'opsz' ${size}`,
      }}
      aria-hidden="true"
    >
      {name}
    </span>
  );
}
