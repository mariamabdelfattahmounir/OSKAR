/**
 * Minimal dependency-free stacked bar chart (SVG). Kept in-house rather than
 * pulling a charting library so the institutional bundle stays lean; swap
 * for Recharts/Visx later if richer interactions are needed.
 */
export default function StackedBarChart({ categories, series, height = 220 }) {
  const totals = categories.map((_, i) => series.reduce((sum, s) => sum + (s.data[i] || 0), 0));
  const max = Math.max(...totals, 1);
  const chartHeight = height - 28;
  const barWidth = 100 / categories.length;

  return (
    <div>
      <svg viewBox={`0 0 ${categories.length * 40} ${height}`} className="w-full" style={{ height }}>
        {categories.map((cat, i) => {
          let yOffset = chartHeight;
          const x = i * 40 + 6;
          return (
            <g key={cat}>
              {series.map((s) => {
                const val = s.data[i] || 0;
                const barHeight = (val / max) * chartHeight;
                yOffset -= barHeight;
                return (
                  <rect
                    key={s.name}
                    x={x}
                    y={yOffset}
                    width={28}
                    height={barHeight}
                    fill={s.color}
                    rx={2}
                  />
                );
              })}
              <text x={x + 14} y={height - 8} textAnchor="middle" fontSize="9" fill="var(--color-text-muted)">
                {cat}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
