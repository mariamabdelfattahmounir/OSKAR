import Icon from './Icon';

export function Card({ children, className = '', hover = false, accent, ...rest }) {
  return (
    <div
      className={`oskar-card ${hover ? 'oskar-card-hover' : ''} ${className}`}
      style={accent ? { borderTop: `3px solid ${accent}` } : undefined}
      {...rest}
    >
      {children}
    </div>
  );
}

export function SectionHeader({ title, subtitle, action, icon }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-4">
      <div>
        <h2 className="flex items-center gap-2 font-heading text-[15px] font-semibold text-ink">
          {icon && <Icon name={icon} size={18} className="text-primary" />}
          {title}
        </h2>
        {subtitle && <p className="mt-0.5 text-body-sm text-ink-muted text-[12.5px]">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatCard({ label, value, valueSuffix, delta, icon, footnote, accent = 'var(--color-primary)', children }) {
  return (
    <Card className="p-4 flex flex-col gap-2" accent={accent}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-bold tracking-wide uppercase text-ink-subtle">{label}</span>
        {icon && (
          <span
            className="flex items-center justify-center w-7 h-7 rounded-md"
            style={{ backgroundColor: 'var(--color-primary-container)', color: 'var(--color-primary)' }}
          >
            <Icon name={icon} size={16} />
          </span>
        )}
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="font-data text-[26px] font-semibold text-ink leading-none">{value}</span>
        {delta && <span className="text-[12px] font-semibold text-success">{delta}</span>}
        {valueSuffix && <span className="text-[12px] text-ink-muted">{valueSuffix}</span>}
      </div>
      {footnote && <p className="text-[12px] text-ink-muted leading-snug">{footnote}</p>}
      {children}
    </Card>
  );
}
