export function ProgressBar({ pct, tone = 'primary', height = 6, trackClassName = '', label }) {
  const color = tone === 'primary' ? 'var(--color-primary)' : tone === 'warning' ? 'var(--color-warning)' : tone === 'danger' ? 'var(--color-danger)' : 'var(--color-secondary)';
  return (
    <div>
      <div
        className={`w-full rounded-full overflow-hidden ${trackClassName}`}
        style={{ height, backgroundColor: 'var(--color-surface-high)' }}
      >
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${Math.min(100, Math.max(0, pct))}%`, backgroundColor: color }}
        />
      </div>
      {label && <div className="mt-1 text-[11px] text-ink-muted">{label}</div>}
    </div>
  );
}

/**
 * Segmented horizontal capacity gauge used for supervisor workload — turns
 * from precision emerald to coral amber once utilization passes 85%, per
 * "Workload Capacity Gauges" in DESIGN.md.
 */
export function CapacityGauge({ pct, capSlots, assigned }) {
  const tone = pct >= 85 ? 'var(--color-warning)' : pct >= 60 ? 'var(--color-info)' : 'var(--color-success)';
  const overCap = assigned > capSlots;
  return (
    <div>
      <div className="w-full h-2 rounded-full overflow-hidden flex gap-[2px]" style={{ backgroundColor: 'var(--color-surface-high)' }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${Math.min(100, pct)}%`, backgroundColor: overCap ? 'var(--color-danger)' : tone }}
        />
      </div>
    </div>
  );
}

/**
 * Dual-ended horizontal gradient CI track with a center indicator, matching
 * the "Modal Overlays with Confidence Meters" spec.
 */
export function ConfidenceMeter({ confidence, ciLow, ciHigh, tone = 'success' }) {
  const color = tone === 'success' ? 'var(--color-success)' : tone === 'warning' ? 'var(--color-warning)' : 'var(--color-info)';
  return (
    <div className="w-40">
      <div className="relative h-1.5 rounded-full" style={{ backgroundColor: 'var(--color-surface-high)' }}>
        <div
          className="absolute top-0 h-1.5 rounded-full"
          style={{ left: `${ciLow}%`, width: `${Math.max(2, ciHigh - ciLow)}%`, backgroundColor: color, opacity: 0.35 }}
        />
        <div
          className="absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full border-2 border-white"
          style={{ left: `calc(${confidence}% - 4px)`, backgroundColor: color }}
        />
      </div>
      <div className="mt-1 font-data text-[10.5px] text-ink-muted">
        CI [{ciLow.toFixed(1)}% - {ciHigh.toFixed(1)}%]
      </div>
    </div>
  );
}
