import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { I18nProvider } from './i18n/I18nContext';
import { ThemeProvider } from './theme/ThemeContext';
import { InstitutionDataProvider } from './context/InstitutionDataContext';
import AppShell from './layout/AppShell';
import InstDashboard from './pages/InstDashboard';
import DomainUserDiscovery from './pages/DomainUserDiscovery';
import SupervisorsView from './pages/SupervisorsView';
import ConnectionRequests from './pages/ConnectionRequests';
import StudiesAnalytics from './pages/StudiesAnalytics';
import PermissionsMatrix from './pages/PermissionsMatrix';
import SetupWizard from './pages/SetupWizard';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <ThemeProvider>
      <I18nProvider>
        <InstitutionDataProvider>
          <BrowserRouter>
            <Routes>
              <Route element={<AppShell />}>
                <Route path="/" element={<InstDashboard />} />
                <Route path="/discovery" element={<DomainUserDiscovery />} />
                <Route path="/supervisors" element={<SupervisorsView />} />
                <Route path="/requests" element={<ConnectionRequests />} />
                <Route path="/studies" element={<StudiesAnalytics />} />
                <Route path="/permissions" element={<PermissionsMatrix />} />
                <Route path="/setup" element={<SetupWizard />} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </InstitutionDataProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}
