import { useTheme } from '../theme/ThemeContext';

// Recreated from the approved Stitch brand mark (oskar_medstat_logo/code.html).
export default function OskarLogo({ height = 36 }) {
  const { isDark } = useTheme();
  const textColor = isDark ? '#eef2f9' : '#0F172A';
  const badgeBg = isDark ? '#1e293b' : '#E2E8F0';
  const badgeText = isDark ? '#a8b6cc' : '#475569';

  return (
    <svg viewBox="0 0 200 48" height={height} width={(height * 200) / 48} fill="none" role="img" aria-label="OSKAR MedStat">
      <rect width="40" height="40" x="4" y="4" rx="10" fill="#0F172A" />
      <path d="M24 12v24M12 24h24" stroke="#00A896" strokeWidth="4" strokeLinecap="round" />
      <circle cx="24" cy="24" r="5" fill="#0F172A" stroke="#38BDF8" strokeWidth="2.5" />
      <circle cx="16" cy="16" r="2.5" fill="#00A896" />
      <circle cx="32" cy="32" r="2.5" fill="#00A896" />
      <text x="52" y="24" fontFamily="Inter, system-ui, sans-serif" fontSize="16" fontWeight="800" fill={textColor} letterSpacing="-0.03em">
        OSKAR
      </text>
      <text x="114" y="24" fontFamily="Inter, system-ui, sans-serif" fontSize="16" fontWeight="500" fill="#00A896" letterSpacing="-0.02em">
        MedStat
      </text>
      <rect x="52" y="28" width="90" height="13" rx="3" fill={badgeBg} />
      <text x="55" y="37.5" fontFamily="Inter, system-ui, sans-serif" fontSize="7.5" fontWeight="700" fill={badgeText} letterSpacing="0.04em">
        INSTITUTIONAL PORTAL
      </text>
    </svg>
  );
}
