import { Outlet } from 'react-router-dom';
import Header from './Header';
import ComplianceTicker from './ComplianceTicker';
import NavTabs from './NavTabs';
import Footer from './Footer';

export default function AppShell() {
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-surface-low)' }}>
      <Header />
      <NavTabs />
      <ComplianceTicker />
      <main className="flex-1 w-full max-w-[1400px] mx-auto px-4 md:px-8 py-6">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
