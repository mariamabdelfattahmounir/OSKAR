import Icon from '../ui/Icon';
import { useI18n } from '../i18n/I18nContext';
import { useComplianceTelemetry } from '../hooks/useComplianceTelemetry';

export default function Footer() {
  const { t } = useI18n();
  const { latencyMs, syncPulse } = useComplianceTelemetry();

  const badges = [
    { icon: 'health_and_safety', label: t('footer.hipaa') },
    { icon: 'fact_check', label: t('footer.gcp') },
    { icon: 'lock', label: t('footer.part11') },
  ];

  return (
    <footer className="w-full border-t mt-8" style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {badges.map((b) => (
              <span
                key={b.label}
                className="inline-flex items-center gap-1.5 h-7 px-2.5 rounded-md text-[11px] font-bold"
                style={{ backgroundColor: 'var(--color-surface-high)', color: 'var(--color-text-secondary)' }}
              >
                <Icon name={b.icon} size={14} />
                {b.label}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-4 text-[11.5px] text-ink-muted whitespace-nowrap">
            <span className="flex items-center gap-1.5">
              <span
                className="inline-block w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: 'var(--color-audit)', opacity: syncPulse ? 1 : 0.4, transition: 'opacity .5s' }}
              />
              {t('footer.auditTrail')}
            </span>
            <span className="hidden sm:inline">{t('ticker.latency')}: <span className="font-data">{latencyMs}ms</span></span>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11.5px] text-ink-subtle">
          <p className="max-w-2xl leading-relaxed">{t('footer.note')}</p>
          <p className="font-data whitespace-nowrap">{t('footer.version')}</p>
        </div>
      </div>
    </footer>
  );
}
