import { NavLink } from 'react-router-dom';
import Icon from '../ui/Icon';
import { useI18n } from '../i18n/I18nContext';
import { useInstitutionData } from '../context/InstitutionDataContext';

const NAV_ITEMS = [
  { to: '/', label: 'nav.overview', icon: 'dashboard', end: true },
  { to: '/discovery', label: 'nav.discovery', icon: 'person_search' },
  { to: '/supervisors', label: 'nav.supervisors', icon: 'groups' },
  { to: '/requests', label: 'nav.requests', icon: 'handshake' },
  { to: '/studies', label: 'nav.studies', icon: 'shield' },
];

export default function NavTabs() {
  const { t } = useI18n();
  const { institution } = useInstitutionData();

  return (
    <div className="w-full border-b" style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 h-11 flex items-center justify-between gap-4 overflow-x-auto">
        <nav className="flex items-center gap-1 h-full">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-1.5 h-full px-3 text-[13px] font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  isActive ? 'border-primary text-primary' : 'border-transparent text-ink-muted hover:text-ink'
                }`
              }
            >
              <Icon name={item.icon} size={16} />
              {t(item.label)}
            </NavLink>
          ))}
        </nav>
        <span
          className="hidden sm:inline-flex items-center gap-1.5 h-6 px-2.5 rounded-full text-[10.5px] font-bold whitespace-nowrap"
          style={{ backgroundColor: 'var(--color-secondary-container)', color: 'var(--color-secondary)' }}
        >
          <Icon name="shield_lock" size={13} />
          {institution.tier}
        </span>
      </div>
    </div>
  );
}
