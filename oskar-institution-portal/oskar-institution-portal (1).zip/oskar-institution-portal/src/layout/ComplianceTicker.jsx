import Icon from '../ui/Icon';
import { useI18n } from '../i18n/I18nContext';
import { useComplianceTelemetry } from '../hooks/useComplianceTelemetry';
import { institution } from '../data/mockData';

/**
 * SPECIAL IMPLEMENTATION NOTICE — Live Compliance Ticker.
 * A subtle, always-on telemetry strip reflecting a live secure clinical
 * environment: regulatory tier, cluster node, session countdown, IRB vault
 * sync state and network latency. Values tick client-side every second so
 * the banner reads as continuously monitored rather than static copy.
 */
export default function ComplianceTicker() {
  const { t } = useI18n();
  const { sessionExpiry, latencyMs, syncPulse } = useComplianceTelemetry();

  return (
    <div
      className="w-full border-b text-[11.5px]"
      style={{ backgroundColor: 'var(--color-secondary-container)', borderColor: 'var(--color-border)' }}
    >
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 h-8 flex items-center justify-between gap-4 overflow-x-auto">
        <div className="flex items-center gap-2 whitespace-nowrap font-semibold text-ink">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary animate-pulse-dot" />
          <span className="tracking-wide">{t('ticker.regulatory')}</span>
          <span className="text-ink-muted font-normal hidden sm:inline">
            · {t('ticker.cluster').replace('ME-CENTRAL-1', institution.cluster)}
          </span>
        </div>
        <div className="flex items-center gap-4 whitespace-nowrap text-ink-muted">
          <span className="flex items-center gap-1">
            <Icon name="schedule" size={13} />
            {t('ticker.sessionExp')}: <span className="font-data text-ink">{sessionExpiry}</span>
          </span>
          <span className="hidden md:flex items-center gap-1">
            <span
              className="inline-block w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: 'var(--color-audit)', opacity: syncPulse ? 1 : 0.4, transition: 'opacity .5s' }}
            />
            {t('ticker.irbVault')}
          </span>
          <span className="hidden lg:flex items-center gap-1">
            <Icon name="bolt" size={13} />
            {t('ticker.latency')}: <span className="font-data text-ink">{latencyMs}ms</span>
          </span>
        </div>
      </div>
    </div>
  );
}
