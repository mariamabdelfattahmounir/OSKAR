import { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../ui/Icon';
import OskarLogo from './OskarLogo';
import { useI18n } from '../i18n/I18nContext';
import { useTheme } from '../theme/ThemeContext';
import { useInstitutionData } from '../context/InstitutionDataContext';

/**
 * Authenticated Workspace Header.
 *
 * NON-NEGOTIABLE RULE (marieam/HEADER.md, RTL_LTR.md): this header is a
 * fixed LTR structural shell in BOTH English and Arabic modes. The brand
 * logo stays physically left, and the utility cluster (language, theme,
 * notifications, profile) stays physically right — never mirrored.
 */
export default function Header() {
  const { t, locale, toggleLocale } = useI18n();
  const { isDark, toggleTheme } = useTheme();
  const { institution } = useInstitutionData();
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  return (
    <header
      className="workspace-header sticky top-0 z-50 w-full border-b backdrop-blur-md"
      style={{ backgroundColor: 'color-mix(in srgb, var(--color-surface) 96%, transparent)', borderColor: 'var(--color-border)' }}
    >
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 h-16 flex items-center justify-between gap-4" style={{ direction: 'ltr' }}>
        {/* LEFT: fixed brand anchor */}
        <Link to="/" className="flex items-center gap-3 shrink-0">
          <OskarLogo height={34} />
        </Link>

        {/* CENTER: security + institution context (hidden on small screens) */}
        <div className="hidden lg:flex items-center gap-2 flex-1 justify-center min-w-0">
          <span
            className="inline-flex items-center gap-1.5 h-7 px-3 rounded-full text-[11px] font-semibold whitespace-nowrap"
            style={{ backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)' }}
          >
            <Icon name="verified_user" size={13} />
            {t('security.encrypted')}
          </span>
          <span
            className="inline-flex items-center gap-1.5 h-7 px-3 rounded-full text-[11px] font-semibold whitespace-nowrap"
            style={{ backgroundColor: 'var(--color-primary-container)', color: 'var(--color-primary)' }}
          >
            <Icon name="account_balance" size={13} />
            {institution.name} ({institution.shortCode})
          </span>
        </div>

        {/* RIGHT: fixed utility cluster — never mirrored in RTL */}
        <div className="flex items-center gap-2.5 shrink-0" style={{ direction: 'ltr' }}>
          <button
            onClick={toggleLocale}
            className="btn btn-outline btn-sm !px-2.5"
            aria-label="Toggle language"
          >
            <span className={locale === 'en' ? 'font-bold text-primary' : 'text-ink-muted'}>EN</span>
            <span className="text-ink-subtle">/</span>
            <span className={locale === 'ar' ? 'font-bold text-primary' : 'text-ink-muted'}>عربي</span>
          </button>

          <button
            onClick={toggleTheme}
            className="btn btn-icon btn-outline"
            aria-label={t('header.switchTheme')}
          >
            <Icon name={isDark ? 'light_mode' : 'dark_mode'} size={19} />
          </button>

          <div className="relative">
            <button
              onClick={() => setNotifOpen((v) => !v)}
              className="btn btn-icon btn-outline relative"
              aria-label={t('header.notifications')}
            >
              <Icon name="notifications" size={19} />
              <span
                className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 rounded-full text-[9px] font-bold text-white"
                style={{ backgroundColor: 'var(--color-danger)' }}
              >
                3
              </span>
            </button>
            {notifOpen && (
              <div
                className="absolute right-0 mt-2 w-72 rounded-card border shadow-level-4 z-50 overflow-hidden"
                style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)', direction: 'ltr' }}
              >
                <div className="px-4 py-3 border-b text-[13px] font-semibold" style={{ borderColor: 'var(--color-border)' }}>
                  {t('header.notifications')}
                </div>
                <ul className="max-h-64 overflow-y-auto">
                  {[
                    'Dr. Rayan Al-Ghamdi requested a supervisor link.',
                    'IRB-2024-0348 amendment pending review.',
                    'HIPAA Safe Harbor recertification confirmed.',
                  ].map((n) => (
                    <li key={n} className="px-4 py-2.5 text-[12.5px] border-b last:border-0 text-ink-muted" style={{ borderColor: 'var(--color-border)' }}>
                      {n}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="w-px h-5 mx-0.5" style={{ backgroundColor: 'var(--color-border)' }} />

          <div className="relative">
            <button
              onClick={() => setProfileOpen((v) => !v)}
              className="flex items-center gap-2.5 pl-1 pr-2 h-9 rounded-md hover:bg-[var(--color-surface-high)]"
            >
              <span
                className="flex items-center justify-center w-8 h-8 rounded-full text-[12px] font-bold text-white shrink-0"
                style={{ backgroundColor: 'var(--color-primary)' }}
              >
                {institution.officer.avatar}
              </span>
              <span className="hidden md:flex flex-col items-start leading-tight text-left">
                <span className="text-[12.5px] font-semibold text-ink">{institution.officer.name}</span>
                <span className="text-[11px] text-ink-muted">{institution.officer.title}</span>
              </span>
              <Icon name="expand_more" size={16} className="text-ink-muted hidden md:inline-block" />
            </button>
            {profileOpen && (
              <div
                className="absolute right-0 mt-2 w-56 rounded-card border shadow-level-4 z-50 overflow-hidden"
                style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)', direction: 'ltr' }}
              >
                <Link
                  to="/setup"
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2 px-4 py-2.5 text-[12.5px] text-ink hover:bg-[var(--color-surface-high)]"
                >
                  <Icon name="settings" size={16} />
                  {t('header.settings')}
                </Link>
                <Link
                  to="/permissions"
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2 px-4 py-2.5 text-[12.5px] text-ink hover:bg-[var(--color-surface-high)]"
                >
                  <Icon name="admin_panel_settings" size={16} />
                  {t('nav.permissions')}
                </Link>
                <button
                  className="flex items-center gap-2 w-full px-4 py-2.5 text-[12.5px] border-t hover:bg-[var(--color-danger-bg)]"
                  style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}
                >
                  <Icon name="logout" size={16} />
                  {t('header.signOut')}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile-only condensed security/institution row */}
      <div className="lg:hidden flex items-center gap-2 px-4 pb-2 overflow-x-auto" style={{ direction: 'ltr' }}>
        <span
          className="inline-flex items-center gap-1 h-6 px-2 rounded-full text-[10px] font-semibold whitespace-nowrap"
          style={{ backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)' }}
        >
          <Icon name="verified_user" size={11} />
          HIPAA · ISO 27001
        </span>
        <span
          className="inline-flex items-center gap-1 h-6 px-2 rounded-full text-[10px] font-semibold whitespace-nowrap"
          style={{ backgroundColor: 'var(--color-primary-container)', color: 'var(--color-primary)' }}
        >
          {institution.shortCode}
        </span>
      </div>
    </header>
  );
}
