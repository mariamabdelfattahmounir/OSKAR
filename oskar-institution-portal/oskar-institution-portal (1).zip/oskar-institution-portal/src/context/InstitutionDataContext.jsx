import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import {
  institution as institutionSeed,
  colleges as collegesSeed,
  departments as departmentsSeed,
  dashboardMetrics,
  activityFeed,
  priorityProtocols,
  matchCandidates as matchCandidatesSeed,
  discoveryStats,
  supervisors as supervisorsSeed,
  supervisorWorkloadSummary,
  researchers as researchersSeed,
  connectionRequests as connectionRequestsSeed,
  connectionRequestSummary,
  studyProductivity,
  departmentOutputSeries,
  statisticalToolDistribution,
  complianceVerification,
  oversightStudies,
  permissionModules,
  subAdmins as subAdminsSeed,
} from '../data/mockData';

const InstitutionDataContext = createContext(null);

/**
 * Simulated network latency for mock-API style interactions, so state
 * transitions (accept / decline / connect / rebalance) feel like real async
 * operations that a future REST/GraphQL layer would perform.
 */
function delay(ms = 450) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function InstitutionDataProvider({ children }) {
  const [institution] = useState(institutionSeed);
  const [colleges] = useState(collegesSeed);
  const [departments] = useState(departmentsSeed);
  const [candidates, setCandidates] = useState(matchCandidatesSeed);
  const [supervisorList, setSupervisorList] = useState(supervisorsSeed);
  const [researcherList] = useState(researchersSeed);
  const [requests, setRequests] = useState(connectionRequestsSeed);
  const [subAdmins, setSubAdmins] = useState(subAdminsSeed);
  const [pendingOps, setPendingOps] = useState({});

  const setOpPending = useCallback((key, val) => {
    setPendingOps((prev) => ({ ...prev, [key]: val }));
  }, []);

  // ---- Domain Discovery / Matching Engine -------------------------------
  const connectCandidate = useCallback(
    async (candidateId) => {
      setOpPending(candidateId, true);
      await delay();
      setCandidates((prev) =>
        prev.map((c) => (c.id === candidateId ? { ...c, status: 'invited' } : c))
      );
      setOpPending(candidateId, false);
    },
    [setOpPending]
  );

  const connectAllHighConfidence = useCallback(async () => {
    setOpPending('bulk-connect', true);
    await delay(700);
    setCandidates((prev) =>
      prev.map((c) => (c.status === 'unlinked' ? { ...c, status: 'invited' } : c))
    );
    setOpPending('bulk-connect', false);
  }, [setOpPending]);

  // ---- Supervisor workload ------------------------------------------------
  const rebalanceSupervisor = useCallback(
    async (supervisorId, delta = -3) => {
      setOpPending(supervisorId, true);
      await delay();
      setSupervisorList((prev) =>
        prev.map((s) => {
          if (s.id !== supervisorId) return s;
          const assigned = Math.max(0, s.assigned + delta);
          const utilizationPct = Math.round((assigned / s.capSlots) * 100);
          const band = utilizationPct >= 85 ? 'high' : utilizationPct >= 60 ? 'moderate' : 'available';
          return { ...s, assigned, utilizationPct, band };
        })
      );
      setOpPending(supervisorId, false);
    },
    [setOpPending]
  );

  const bulkRebalance = useCallback(async () => {
    setOpPending('bulk-rebalance', true);
    await delay(800);
    setSupervisorList((prev) =>
      prev.map((s) => {
        if (s.band !== 'high') return s;
        const assigned = Math.max(0, s.assigned - 2);
        const utilizationPct = Math.round((assigned / s.capSlots) * 100);
        const band = utilizationPct >= 85 ? 'high' : utilizationPct >= 60 ? 'moderate' : 'available';
        return { ...s, assigned, utilizationPct, band };
      })
    );
    setOpPending('bulk-rebalance', false);
  }, [setOpPending]);

  // ---- Connection requests -------------------------------------------------
  const decideRequest = useCallback(
    async (requestId, decision) => {
      setOpPending(requestId, true);
      await delay();
      setRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: decision } : r))
      );
      setOpPending(requestId, false);
    },
    [setOpPending]
  );

  const batchAcceptPending = useCallback(
    async (ids) => {
      setOpPending('batch-accept', true);
      await delay(700);
      setRequests((prev) =>
        prev.map((r) => (ids.includes(r.id) ? { ...r, status: 'accepted' } : r))
      );
      setOpPending('batch-accept', false);
    },
    [setOpPending]
  );

  const resendPing = useCallback(
    async (requestId) => {
      setOpPending(`ping-${requestId}`, true);
      await delay(500);
      setOpPending(`ping-${requestId}`, false);
    },
    [setOpPending]
  );

  // ---- Sub-admin permissions ----------------------------------------------
  const togglePermission = useCallback((adminId, moduleName, key) => {
    setSubAdmins((prev) =>
      prev.map((a) => {
        if (a.id !== adminId) return a;
        const current = a.permissions[moduleName] || {};
        return {
          ...a,
          permissions: {
            ...a.permissions,
            [moduleName]: { ...current, [key]: !current[key] },
          },
        };
      })
    );
  }, []);

  const addSubAdmin = useCallback((name, role) => {
    const id = `ADMIN-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    const blankPerms = Object.fromEntries(
      permissionModules.map((m) => [m, { view: true, edit: false, approve: false, export: false }])
    );
    setSubAdmins((prev) => [...prev, { id, name, role, permissions: blankPerms }]);
  }, []);

  const value = useMemo(
    () => ({
      institution,
      colleges,
      departments,
      dashboardMetrics,
      activityFeed,
      priorityProtocols,
      discoveryStats,
      candidates,
      connectCandidate,
      connectAllHighConfidence,
      supervisors: supervisorList,
      supervisorWorkloadSummary,
      rebalanceSupervisor,
      bulkRebalance,
      researchers: researcherList,
      requests,
      connectionRequestSummary,
      decideRequest,
      batchAcceptPending,
      resendPing,
      studyProductivity,
      departmentOutputSeries,
      statisticalToolDistribution,
      complianceVerification,
      oversightStudies,
      permissionModules,
      subAdmins,
      togglePermission,
      addSubAdmin,
      pendingOps,
    }),
    [
      institution,
      colleges,
      departments,
      candidates,
      connectCandidate,
      connectAllHighConfidence,
      supervisorList,
      rebalanceSupervisor,
      bulkRebalance,
      researcherList,
      requests,
      decideRequest,
      batchAcceptPending,
      resendPing,
      subAdmins,
      togglePermission,
      addSubAdmin,
      pendingOps,
    ]
  );

  return <InstitutionDataContext.Provider value={value}>{children}</InstitutionDataContext.Provider>;
}

export function useInstitutionData() {
  const ctx = useContext(InstitutionDataContext);
  if (!ctx) throw new Error('useInstitutionData must be used within InstitutionDataProvider');
  return ctx;
}
